# START HERE: your 72-hour plan

## What you're selling (Brazil first, in Brazilian Portuguese)
| Family | Main product (R$27) | Checkout add-on | Upsell |
|---|---|---|---|
| 1. Caderno do Casal ✅ READY | 52 Encontros | 100 Cartões, R$12.90 | Devocional 30 Dias, R$27 |
| 2. Planner Financeiro 2027 ✅ READY | Planner (PDF) | Desafio 52 Semanas, R$9.90 | Guia Saia das Dívidas + Spreadsheet, R$37 |
| 3. Kit Natal na Escola ⏳ | 100+ activities | Tags and cards, R$12.90 | Natal na EBD, R$27 |
| Mega Kit Black Friday | all 9 products: R$67 on 27–30 November (normal price R$97) | | |

Family 3's sales copy is already in 03-VENDAS. Ask me in a new session to finish its products and the step-by-step Lovable prompts.

## Investment
- **USD 0 to start:** Lovable Pro and your domains (you have them), free Canva, free CapCut, Gemini, Google Sheets.
- **Ads only after organic sales:** R$20–30 a day per product for 5–7 days (about USD 30–40 per test). Meta adds about 12% Brazilian tax. Scale only while the cost per sale is lower than the average order value.

## 72 hours
1. **Hours 0–6:** Generate the covers in Gemini (04-PROMPTS) and add the titles in Canva. Upload Family 1 to EscalePay at BRL prices. Do a TEST PURCHASE by Pix with someone in Brazil and check the payout. Open a Hotmart account as a backup (Brazilian trust and affiliates).
2. **Hours 6–12:** Build the sales page in Lovable from the copy in 03-VENDAS (one section at a time), connect your domain, and link the buttons to the EscalePay checkout.
3. **Hours 12–24:** Create faceless accounts (TikTok, Reels, Pinterest) and post 5 videos flipping through the PDF pages.
4. **Day 2:** Open affiliates at 50% and invite 30 creators and pages in the niche.
5. **Day 3:** Launch. Reply to everything. Fix what visitors show you.
6. **Day 5:** Family 2. **Day 8:** Family 3. **27–30 November:** Mega Kit.

## Rules
Withdraw often. Never promise results. No fake testimonials. Honour the 7-day guarantee (Brazil's consumer law, CDC). Read the course (01-CURSO) chapter by chapter and do the challenges.
