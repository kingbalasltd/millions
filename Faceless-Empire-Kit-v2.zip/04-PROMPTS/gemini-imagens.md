# Gemini prompts: covers, mockups and posts

**Golden rule:** generate the art **WITHOUT TEXT**, then add the title in Canva. AI is unreliable at writing Portuguese accents. Use the same style words in every prompt so all images look consistent. Never use real brands, celebrities or characters.

## Family 1: Caderno do Casal (terracotta #8E3B2F, blush pink #E9C9BE, cream #FBF6F0)
1. **Cover (3:4):** "Elegant minimalist book cover art, warm terracotta and blush pink palette, abstract line-art of two hands holding coffee cups on a cream background, soft paper texture, romantic and calm, generous empty space at the top for a title, no text, no letters"
2. **Book mockup (1:1):** "Photorealistic mockup of a printed spiral journal open on a wooden table, cream pages with handwritten notes, two coffee cups, soft morning light, terracotta accents, shallow depth of field, no readable text"
3. **Tablet mockup (4:5):** "Tablet on a cozy sofa showing an elegant journal page, blanket and warm lamp light, terracotta and cream tones, lifestyle photo, no readable text"
4. **Question cards (1:1):** "Flat lay of printed question cards in terracotta, rose, navy and sage, spread on linen with a candle and wine glasses, top view, no readable text"
5. **Devotional (3:4):** "Soft watercolor of an open Bible and two hands in prayer, cream and terracotta palette, gentle light, space for a title, no text"
6. **Reels/TikTok background (9:16):** "Cozy evening scene, couple silhouettes on a sofa from behind, warm lamp, terracotta and cream, cinematic, empty area in the middle for overlaid text, no text"
7. **Pinterest pin (2:3):** "Aesthetic flat lay of a printed couples journal, pen, dried flowers, cream and terracotta, top view, empty space at the top for a title, no text"

## Family 2: Planner Financeiro 2027 (forest green #1F5135, mint #CFE6D8, gold #C9A227)
8. **Cover (3:4):** "Modern minimalist cover art, forest green and gold, abstract rising bar chart made of coins, clean geometric shapes, premium feel, space for a title, no text"
9. **Planner mockup (1:1):** "Photorealistic printed financial planner on a desk with a calculator, a pen, coins and a coffee cup, green and gold accents, natural light, no readable text"
10. **Spreadsheet mockup (16:9):** "Laptop on a clean desk showing a colorful spreadsheet dashboard with green bar charts, plant in the background, no readable text"
11. **52 Weeks challenge (4:5):** "Glass jar filling with coins and rolled banknotes, green and gold palette, soft background, sense of progress, no text"
12. **Background (9:16):** "Top view of a desk with a planner, coins and a phone, green and cream tones, empty space for text, no text"
13. **Pinterest (2:3):** "Aesthetic flat lay of printed budget pages with a green pen and a cup of coffee, January vibe, empty space at the top, no text"

## Family 3: Kit Natal na Escola (red #B3122E, green #1E6B3A, gold #E0A526)
14. **Cover (3:4):** "Cheerful Brazilian summer Christmas illustration for kids, sun, decorated Christmas tree, stars and gifts, flat vector style, red, green and gold, white background, space for a title, no text"
15. **Kit mockup (1:1):** "Stack of printed children's activity sheets with crayons and scissors on a school desk, Christmas decorations, bright natural light, no readable text"
16. **Tags (1:1):** "Flat lay of printed Christmas gift tags and kraft paper gift boxes, red and green ribbons, top view, no readable text"
17. **Sunday school / EBD (3:4):** "Gentle flat illustration of the nativity scene for children, stable, star, shepherds, warm colors, simple shapes, space for a title, no text"
18. **Background (9:16):** "Classroom table with Christmas worksheets and colored pencils, festive but school-appropriate, empty center area for text, no text"

## Bundle: Mega Kit Black Friday
19. **Mockup (16:9):** "Product bundle mockup: printed couples journal, financial planner and Christmas activity kit arranged together with a tablet, premium studio lighting, black and gold Black Friday mood, no readable text"

**In Canva:** place the image, add the title in Serif Bold, export at 1080×1350 (feed), 1080×1920 (Reels/Stories), 1000×1500 (Pinterest) and 1600×2400 (cover).
