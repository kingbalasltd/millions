# 3 Kit Natal na Escola: textos de venda (PT-BR, revisados)

**SEO:** Kit Natal na Escola: 100+ Atividades de Natal para Imprimir | R$27

**Meta:** Mais de 100 atividades de Natal laicas para Educação Infantil e Fundamental I: traçado, caça-palavras, historinhas com interpretação, matemática e gabaritos. PDF por R$27.


## 01 · Hero

**Mais de 100 atividades de Natal para imprimir, com gabarito, prontas para os últimos dias de aula**

Kit laico para Educação Infantil e Fundamental I: traçado, labirintos, caça-palavras, historinhas com interpretação, matemática natalina e muito mais. Arquivo em PDF por R$27, pagamento único.

Dezembro é corrido. Tem festa, apresentação, parecer, conselho de classe e ainda aquela turma agitada perguntando: “Prô, o que a gente vai fazer hoje?”.

Com o **Kit Natal na Escola**, você abre o arquivo, escolhe a atividade do dia e imprime. Sem garimpar folhinha solta na internet, sem conteúdo religioso que não cabe na sua escola e sem ficar sem a resposta na hora de corrigir.

São mais de 100 atividades organizadas por tipo, do traçado para os pequenos à interpretação de texto e à matemática para quem já lê e escreve. Tudo por R$27: menos de 30 centavos por atividade.

- Mais de 100 atividades de Natal organizadas por tipo
- Conteúdo laico: pode ser usado em escola pública e particular
- Gabarito das atividades que têm resposta certa
- Da Educação Infantil ao Fundamental I: você escolhe o que combina com a sua turma
- Pix ou cartão, com acesso liberado após a confirmação do pagamento
- Reembolso em até 7 dias, se o kit não servir para você

[BOTÃO] Quero o Kit Natal na Escola por R$27

_Design (para o Lovable): Two-column hero on desktop (copy left, image right), stacked on mobile with image below the headline. Image slot [MOCKUP_HERO]: overhead flat-lay of printed A4 activity sheets (maze, word search, color-by-number) on a wooden school desk with crayons, pencils and a small paper Christmas tree; only adult hands visible, no children's faces. Warm palette: red, forest green, cream, with a mustard accent for buttons. Price R$27 shown next to the CTA button in large type. Small trust line under the button: 'Pix ou cartão | Reembolso em até 7 dias'. No countdown timers, no fake badges, no 'mais vendido'. [check: before going live, make a real test purchase from a Brazilian buyer by Pix and by card and confirm the EscalePay checkout shows and charges R$27 in reais; if it charges in another currency, the price claims on this page must change.]_

## 02 · Problema

**Você não precisa de mais uma noite procurando atividade de Natal na internet**

O problema não é falta de ideia. É falta de tempo para juntar, conferir e imprimir tudo.

O fim do ano letivo chega com tudo ao mesmo tempo: fechamento de notas, pareceres, ensaio da apresentação, decoração da sala, lembrancinha das famílias.

E no meio disso você ainda precisa de atividades que segurem a atenção da turma nos últimos dias, justamente quando ninguém mais quer saber de caderno.

Aí começa a busca. Um caça-palavras num site, um labirinto em outro, uma folhinha com marca d'água, outra que sai borrada na impressão, uma que fala de presépio e não serve para a sua escola, outra sem gabarito. Duas horas depois, você tem uma pasta bagunçada e a aula de amanhã ainda não está pronta.

Não é falta de vontade nem de criatividade. É que dezembro não deixa sobrar tempo.

- Atividades soltas, de fontes diferentes, com qualidade irregular
- Arquivos em baixa resolução que saem borrados no xerox
- Material com conteúdo religioso que não se encaixa na escola laica
- Folhinhas sem gabarito, que viram mais trabalho na correção
- Tempo de descanso que vai embora procurando material

[BOTÃO] Quero resolver isso com um kit pronto

_Design (para o Lovable): Light cream background, single centered column, max ~680px width. Optional image slot [MOCKUP_PROBLEM]: messy desk with scattered loose printouts, a laptop with many browser tabs open (generic tabs, no real brand logos) and a cold cup of coffee, evening lighting, no faces. Bullets styled as a list with a soft red 'x' icon. Keep the tone empathetic, not dramatic. Do not reuse this headline as a Meta ad headline without review; ad versions should describe the product, not the reader._

## 03 · Por que este kit existe

**Por que a gente montou este kit**

Uma pergunta simples: o que realmente ajuda quem ensina em dezembro?

Somos a [Nome da marca], uma marca de materiais digitais para imprimir. A gente não está na sala de aula com você, e não vai fingir que está.

Mas montou este kit com uma regra clara: cada página precisa ser útil numa sala de verdade. Por isso ele tem gabarito. Por isso é laico. Por isso vai do traçado da Educação Infantil às cruzadinhas e à matemática do Fundamental I.

A gente não vai prometer que o seu dezembro fica tranquilo, porque isso depende de muita coisa. Mas a parte do “o que eu dou para a turma fazer hoje?” pode estar resolvida antes de dezembro começar.

- Feito para imprimir em casa ou na escola
- Organizado por tipo de atividade, para você achar o que precisa mais rápido
- Pensado para turmas diferentes, da Educação Infantil ao Fundamental I
- Ilustrações originais ou licenciadas, sem personagens de marcas ou desenhos famosos

[BOTÃO] Ver o que vem no kit

_Design (para o Lovable): Brand-voice section, no person photo and no avatar (faceless brand). Use the brand logo or a small illustrated icon (pencil + star). Image slot [MOCKUP_BRAND]: neat stack of printed sheets tied with red ribbon next to a pencil cup. Soft green background band to separate from the problem section. Do not add any founder story, team size, years of experience or teaching credentials: none of that exists._

## 04 · Solução

**Kit Natal na Escola: abra, escolha, imprima**

Mais de 100 atividades natalinas num só lugar, prontas para os últimos dias de aula.

Em vez de montar o material do zero, você já começa com o kit organizado por tipo de atividade. É só escolher o que combina com a sua turma e com o tempo que você tem.

Serve para a atividade de fixação, para a criança que termina antes, para o dia de chuva sem recreio, para a tarefa de casa e para a última semana, quando a rotina já mudou e você precisa de uma proposta com começo, meio e fim.

- Para a última semana de aula, quando a rotina muda
- Para quem termina a atividade antes dos colegas
- Para dia de chuva sem recreio
- Para tarefa de casa leve e temática
- Para o encerramento do ano, com certificados para entregar
- Para reforço escolar e homeschool

[BOTÃO] Quero o kit por R$27

_Design (para o Lovable): Three-card grid on desktop (Abra / Escolha / Imprima) with simple line icons, stacked on mobile. Image slot [MOCKUP_SOLUTION]: tablet showing the PDF table of contents next to printed sheets, clean desk. Use cream cards with green headers._

## 05 · O que vem no kit

**O que você encontra dentro do Kit Natal na Escola**

Mais de 100 atividades com tema de Natal, sem conteúdo religioso, com gabarito onde há resposta.

O kit foi organizado por tipo de atividade, para você montar a sequência da semana com mais facilidade.

Tem atividades mais simples, para quem ainda está desenvolvendo a coordenação motora, e atividades que pedem leitura, interpretação e raciocínio, para as turmas do Fundamental I.

Tudo em PDF pronto para imprimir [check: confirmar formato A4 e número total de páginas antes de publicar].

- Traçado e coordenação motora com tema natalino
- Ligue os pontos
- Labirintos de Natal
- Colorir por números
- Caça-palavras com vocabulário de Natal
- Cruzadinhas
- 10 historinhas de Natal com perguntas de interpretação
- Propostas de produção de texto
- Matemática natalina com tema de Natal [check: confirmar se inclui contas e situações-problema e descrever aqui]
- Sudoku infantil
- Calendário do Advento de 24 dias: uma contagem regressiva para o Natal com a turma, sem conteúdo religioso
- Certificados para entregar no encerramento do ano
- Gabaritos das atividades que têm resposta

[BOTÃO] Quero todas essas atividades por R$27

_Design (para o Lovable): Most important section. Image slots: [MOCKUP_INSIDE_1] spread of tracing + dot-to-dot pages; [MOCKUP_INSIDE_2] word search + crossword pages with pencil; [MOCKUP_INSIDE_3] story page with interpretation questions; [MOCKUP_INSIDE_4] Christmas maths + kids sudoku; [MOCKUP_INSIDE_5] 24-day Advent countdown calendar and certificate; [MOCKUP_INSIDE_6] answer key page. Use a carousel or 2x3 grid; each image with a short caption. Mockups must show real pages from the final file. All illustrations must be original or properly licensed: no copyrighted characters (e.g., no Bobbie Goods or similar). Export at print resolution (300 dpi) before claiming the files print sharply. Bullets in two columns on desktop with green check icons. Replace the [check] notes with real page count and real maths content before going live._

## 06 · Adicional opcional

**Na página de pagamento: Tags, Etiquetas e Cartões de Natal para imprimir**

Opcional, por mais R$12,90. Você só leva se fizer sentido para você.

Se você costuma entregar uma lembrancinha para a turma ou mandar um recado carinhoso para as famílias no fim do ano, este adicional ajuda a dar o acabamento.

São tags, etiquetas e cartões com tema de Natal, prontos para imprimir, recortar e usar. Ele aparece como uma caixinha para marcar no checkout. Se não quiser, é só deixar desmarcado: o Kit Natal na Escola continua completo sem ele.

- Tags para presentes e lembrancinhas
- Etiquetas para saquinhos, potinhos e caixinhas
- Cartões de Natal para alunos e famílias
- [check: informar quantidade de modelos de cada item]

[BOTÃO] Quero o kit e ver o adicional no checkout

_Design (para o Lovable): Smaller, secondary section with a dashed border to read as optional. Image slot [MOCKUP_BUMP]: printed gift tags tied to small kraft paper bags and a folded Christmas card, close-up. Show '+ R$12,90 (opcional)' clearly. Do not present it as free or as a bonus. The checkbox must start UNCHECKED in the checkout._

## 07 · Como funciona

**Como funciona, em 3 passos**

Sem frete, sem espera pelos Correios.

Você compra, recebe o acesso assim que o pagamento é confirmado e já pode imprimir. Se precisar, guarda o arquivo no celular, no computador ou no Google Drive para usar quando quiser.

- 1. Compre com Pix ou cartão na página de pagamento
- 2. Receba o acesso por e-mail após a confirmação do pagamento [check: confirmar como e em quanto tempo a EscalePay entrega o arquivo]
- 3. Baixe, imprima e use com a sua turma quantas vezes precisar

[BOTÃO] Comprar agora com Pix ou cartão

_Design (para o Lovable): Horizontal 3-step timeline on desktop, vertical on mobile, numbered circles in mustard. Image slot [MOCKUP_HOWITWORKS]: phone screen showing a generic payment confirmation next to a printer outputting a Christmas activity sheet (generic UI, no real bank or Pix logos). [check: only keep 'Pix' on the page after a real Pix test purchase from a Brazilian buyer goes through on EscalePay.]_

## 08 · Para quem é

**Este kit é para você se...**

Feito para adultos que ensinam crianças, em sala de aula ou em casa.

Ele foi pensado para quem precisa de material bom e rápido no fim do ano, sem abrir mão de atividades com propósito pedagógico.

- Você é professora ou professor de Educação Infantil ou Fundamental I
- Você é da coordenação pedagógica e quer indicar atividades de Natal para a equipe (cada professor usa a sua própria cópia) [check: definir se haverá licença para escola/equipe]
- Você faz homeschool e quer um dezembro temático com os seus filhos
- Você dá reforço escolar ou aulas particulares
- Você atua em projeto social, contraturno ou biblioteca com crianças
- Você ensina na EBD: este kit é laico, mas logo depois da compra mostramos um kit bíblico separado e opcional

[BOTÃO] Sou eu, quero o kit

_Design (para o Lovable): Two-column list with green check icons. Image slot [MOCKUP_FORWHO]: adult hands organizing printed sheets into colorful folders labeled by grade (generic labels). No children's faces._

## 09 · Para quem não é

**Este kit não é para você se...**

Melhor saber antes de comprar.

A gente prefere que você compre sabendo exatamente o que vai receber.

- Você quer um produto físico: este é um arquivo digital para imprimir
- Você quer atividades bíblicas neste kit: ele é laico (o kit bíblico é separado)
- Você precisa de arquivos editáveis [check: confirmar se o PDF é editável]
- Você quer revender, distribuir ou publicar as atividades
- Você precisa de atividades com códigos da BNCC indicados em cada página [check: o kit não traz essa indicação, a menos que seja incluída]
- Você espera que um material garanta mais aprendizado, notas melhores ou uma turma mais calma: nenhum kit consegue prometer isso
- Você não tem como imprimir nem projetar o material

[BOTÃO] Entendi, quero o kit mesmo assim

_Design (para o Lovable): Same layout as for_who but with neutral grey 'x' icons. Keep it compact. No image needed._

## 10 · Oferta

**Tudo o que você leva por R$27**

Pagamento único, por Pix ou cartão. Sem mensalidade.

A gente não vai colocar um “valor real” riscado para parecer desconto. O preço do Kit Natal na Escola é R$27, e é isso que você paga.

Fazendo a conta: são mais de 100 atividades, então cada uma sai por menos de 30 centavos. E você pode imprimir quantas vezes precisar para usar com a sua turma.

- Mais de 100 atividades de Natal laicas
- Traçado, ligue os pontos, labirintos e colorir por números
- Caça-palavras, cruzadinhas e sudoku infantil
- 10 historinhas com perguntas de interpretação
- Propostas de produção de texto
- Matemática natalina
- Calendário do Advento de 24 dias (contagem regressiva, sem conteúdo religioso)
- Certificados de encerramento do ano
- Gabaritos das atividades que têm resposta
- Licença para imprimir e usar com as suas turmas
- Reembolso em até 7 dias (direito de arrependimento)

[BOTÃO] Quero o Kit Natal na Escola por R$27

_Design (para o Lovable): Boxed offer card centered, cream background with red border. Image slot [MOCKUP_OFFER]: 3D-style product mockup of the PDF cover (title 'Kit Natal na Escola') with fanned-out pages behind it. Price 'R$27' very large, 'Pix ou cartão' beneath. [check: only add instalment info if EscalePay confirms it for Brazilian buyers.] No strikethrough price, no timer, no 'últimas unidades'._

## 11 · Garantia

**Você tem 7 dias para decidir com calma**

É o seu direito de arrependimento, previsto no Código de Defesa do Consumidor (art. 49), e a gente cumpre sem complicação.

Baixe o kit, abra as páginas e veja se ele serve para a sua turma.

Se não fizer sentido para você, peça o reembolso em até 7 dias após a compra pelo [contato]. Você não precisa justificar o motivo e recebe o valor de volta [check: confirmar com a EscalePay como e em quanto tempo o estorno acontece no Pix e no cartão].

- Prazo: 7 dias a partir da compra
- Pedido simples pelo [contato]
- Sem precisar explicar o motivo

[BOTÃO] Quero o kit, com 7 dias para decidir

_Design (para o Lovable): Centered block with a simple shield or seal icon reading '7 dias' (original design, not mimicking any official seal or Procon/government mark). Light green background. Keep text short and calm. Present the 7 days as a legal right the brand honors, not as an exclusive extra._

## 12 · Depoimentos

**O que dizem as pessoas que já usaram**

[Seção oculta até ter depoimentos reais]

[Depoimento real do primeiro cliente]

[Depoimento real do segundo cliente]

[Depoimento real do terceiro cliente]

Instruções: use apenas mensagens reais de compradores, com autorização por escrito para publicar. Mostre só o que a pessoa autorizou (por exemplo, primeiro nome e cidade, ou iniciais). Não edite o sentido do texto, não crie depoimentos, não use fotos de banco de imagem e não publique fotos de crianças. Se usar prints de mensagens, apague dados pessoais. Não publique depoimentos que prometam resultados (como “minha turma melhorou as notas”). Nunca ofereça benefício em troca de avaliação positiva.

- [Depoimento real do primeiro cliente]
- [Depoimento real do segundo cliente]
- [Depoimento real do terceiro cliente]

[BOTÃO] Quero o meu kit também

_Design (para o Lovable): HIDE this section until at least 3 real, authorized testimonials exist. Layout: 3 cards with quote text, first name or initials, and role (e.g., 'professora do 2º ano', only if the buyer said so). Optional image slot [MOCKUP_TESTIMONIAL]: real photo sent by a buyer of printed sheets (no children's faces, only with written permission). Never use AI-generated people._

## 13 · Introdução ao FAQ

**Ficou alguma dúvida?**

Respondemos as perguntas que mais aparecem antes da compra.

Se a sua pergunta não estiver aqui, fale com a gente pelo [contato]. A resposta vem por escrito, para você decidir com segurança.


[BOTÃO] Ver perguntas frequentes

_Design (para o Lovable): Short intro above an accordion FAQ (questions collapsed by default). Neutral background._

## 14 · Chamada final

**Imagine chegar em dezembro com a pasta do Natal já pronta**

Mais de 100 atividades laicas, com gabarito, por R$27.

Em vez de procurar folhinha às onze da noite, você abre o arquivo, escolhe e imprime. Assim, pode sobrar mais tempo para o que só você faz: estar presente com a sua turma nos últimos dias do ano.

E se o kit não servir para você, tem 7 dias para pedir o reembolso.

- Acesso após a confirmação do pagamento
- Pix ou cartão
- Reembolso em até 7 dias

[BOTÃO] Quero o Kit Natal na Escola por R$27

_Design (para o Lovable): Full-width deep green band with cream text and a large mustard button. Image slot [MOCKUP_FINAL]: tidy desk with a printed stack of Christmas activities, a ribbon and a mug, golden afternoon light. No urgency elements._

## 15 · Rodapé

**Kit Natal na Escola**

Produto digital. Nenhum item físico é enviado.

Vendido por: [Nome]

Identificação: [NUIT/identificação — check]

Endereço: [endereço completo — check]

Contato: [contato]

Pagamento processado por [EscalePay — check: nome e dados conforme a plataforma].

Material educativo para uso com a sua turma, seus alunos ou sua família. É proibido revender, distribuir ou publicar o conteúdo. Ilustrações próprias ou licenciadas, sem personagens protegidos por direitos autorais ou marcas registradas.

- Política de Privacidade (LGPD)
- Termos de Uso e Licença
- Política de Reembolso (7 dias)
- Fale com a gente: [contato]

[BOTÃO] Fale com a gente

_Design (para o Lovable): Simple dark footer, small text, links to Política de Privacidade (in Portuguese, LGPD), Termos, and Reembolso pages. Seller identification (name, identification number, address, contact) must be visible on every page of the funnel, per Decreto 7.962/2013 [check: confirm which identification a Mozambique-based seller should display]. Copyright line: '© 2026 [Nome]'. No image._

## FAQ

**O kit é físico ou digital?**

É digital. Você recebe um arquivo em PDF para baixar e imprimir. Nada é enviado pelos Correios.

**Como eu recebo o acesso?**

Depois que o pagamento é confirmado, você recebe o acesso por e-mail [check: confirmar o fluxo e o tempo de entrega da EscalePay e o tempo de confirmação do Pix]. Se não encontrar o e-mail, olhe a caixa de spam ou a aba promoções e fale com a gente pelo [contato].

**Tem conteúdo religioso?**

Não. O Kit Natal na Escola é laico, pensado para escolas públicas e particulares. O calendário do Advento é uma contagem regressiva de 24 dias para o Natal, sem conteúdo religioso. Se você dá aula na EBD, existe um kit bíblico separado, o Natal na EBD, que aparece como oferta opcional depois da compra.

**Para qual idade ou ano escolar ele serve?**

Para Educação Infantil e Fundamental I. Atividades como traçado, ligue os pontos e colorir por números atendem os menores; historinhas com interpretação, produção de texto, cruzadinhas, matemática natalina e sudoku servem melhor para quem já lê e escreve. Você escolhe o que combina com a sua turma.

**As atividades seguem a BNCC?**

As atividades trabalham coordenação motora, leitura, interpretação, escrita e raciocínio, mas as páginas não trazem os códigos da BNCC indicados [check: confirmar; se os códigos forem incluídos, atualizar esta resposta]. Você pode encaixar cada atividade no seu planejamento.

**Posso imprimir quantas vezes quiser?**

Sim, para usar com a sua turma, seus alunos ou sua família. O que não é permitido é revender, distribuir o arquivo ou publicar as atividades na internet.

**Posso usar de novo no Natal do ano que vem?**

Sim. O arquivo fica com você, e você pode imprimir de novo para as suas próximas turmas [check: confirmar nos Termos de Uso].

**Posso compartilhar com outras professoras da escola?**

A licença é individual: cada professora ou professor deve ter a sua cópia [check: definir se haverá licença para escola/equipe]. Assim a gente consegue continuar produzindo material com preço acessível.

**Preciso de impressora colorida?**

Não necessariamente. Muitas atividades são feitas para a criança colorir ou completar [check: confirmar quais páginas ficam boas em preto e branco e informar aqui]. Use papel sulfite comum.

**As atividades têm gabarito?**

Sim. As atividades que têm resposta certa, como caça-palavras, cruzadinhas, labirintos, matemática e sudoku, vêm com gabarito para facilitar a correção.

**O arquivo é editável?**

[check: confirmar] O kit é entregue em PDF pronto para imprimir. Os certificados têm espaço para você preencher o nome da criança à mão depois de imprimir.

**Como posso pagar?**

Por Pix ou cartão. [check: só mencionar parcelamento se a EscalePay confirmar essa opção para compradores do Brasil.]

**O valor é cobrado em reais?**

Sim, o preço é R$27. [check: confirmar com uma compra-teste que o checkout da EscalePay mostra e cobra o valor em reais para compradores no Brasil; se cobrar em outra moeda, informar aqui que pode haver IOF e conversão no cartão.]

**E se eu não gostar?**

Você tem 7 dias a partir da compra para pedir o reembolso, conforme o art. 49 do Código de Defesa do Consumidor, sem precisar justificar. É só escrever para o [contato].

**Quem está vendendo este produto?**

O kit é produzido e vendido por [Nome], identificação [NUIT/identificação]. Os dados completos e o contato estão no rodapé desta página. O pagamento é processado pela plataforma [EscalePay — check].


## Checkout: order bump

**Sim, quero adicionar as Tags, Etiquetas e Cartões de Natal por mais R$12,90**

Para fechar o ano com carinho: tags para lembrancinhas, etiquetas para saquinhos e potinhos e cartões de Natal para alunos e famílias, prontos para imprimir e recortar. Combina com o Kit Natal na Escola e é entregue junto com ele. É opcional: marque a caixinha só se for usar. [check: informar quantidade de modelos]


## /obrigado

**Compra confirmada: o Kit Natal na Escola é seu**



Obrigado pela confiança. Agora é só baixar o arquivo e começar a planejar.

O acesso foi enviado para o e-mail que você usou na compra [check: confirmar fluxo de entrega da EscalePay]. Se não chegar em alguns minutos, confira o spam e a aba promoções, ou fale com a gente pelo [contato].

Lembre: você tem 7 dias a partir da compra para pedir reembolso se o kit não servir para você.

- Abra o e-mail de acesso e baixe o PDF
- Salve uma cópia no Google Drive ou no computador para não perder
- Imprima uma página de teste para conferir a qualidade na sua impressora
- Separe as atividades por semana ou por turma, do jeito que preferir
- Guarde os gabaritos numa pasta à parte para agilizar a correção

[upsell_teaser] Planejando também o ano que vem? Conheça o Planner Financeiro 2027 (R$27) e o Caderno do Casal: 52 Encontros para Reconectar (R$27), ou o Mega Kit 2027 com os 9 produtos das três coleções: R$67 de 27 a 30 de novembro de 2026, depois R$97. Atenção: o Mega Kit inclui este kit que você já tem. [check: confirmar se o Mega Kit estará à venda antes de 27 de novembro e por qual preço]

## /oferta-especial (upsell)

**Para quem também dá aula na Escola Bíblica Dominical: Natal na EBD**

Kit de Atividades Bíblicas por R$27, que você pode adicionar ao seu pedido agora.

O Kit Natal na Escola é laico, de propósito. Mas muitas professoras que dão aula de segunda a sexta também ajudam na EBD no domingo, e o Natal é uma época em que a classe infantil costuma precisar de material.

O Natal na EBD traz 8 lições prontas, artesanatos, caça-palavras, cruzadinhas e um roteiro de teatrinho para a apresentação da classe. Os textos usam referências bíblicas e paráfrases, para você ler a passagem na versão da Bíblia que a sua igreja usa.

Se você pagou com cartão, basta clicar no botão para adicionar ao pedido, sem digitar os dados de novo [check: confirmar como o one-click funciona com Pix na EscalePay]. Também vale o reembolso em até 7 dias.

Se não for o seu caso, é só clicar em “não”: o seu pedido continua exatamente como está.

- 8 lições de Natal prontas para a classe infantil
- Artesanatos para fazer com as crianças
- Caça-palavras e cruzadinhas bíblicas
- Roteiro de teatrinho para a apresentação de Natal
- Referências bíblicas e paráfrases, sem citação literal de versões
- Arquivo digital para imprimir, com acesso junto com o seu kit

[cta_yes] Sim, quero adicionar o Natal na EBD por R$27

[cta_no] Agora não. Quero continuar só com o meu pedido.

## /segunda-chance (downsell)

**Tudo bem. E se o Natal na EBD custasse menos?**

O mesmo Kit de Atividades Bíblicas, completo, por R$17 [check: preço do downsell não definido no catálogo para esta coleção].

Talvez R$27 não caiba agora, ou você ainda não tenha certeza se vai usar com a sua classe.

Por isso, nesta página, você pode levar o Natal na EBD completo por R$17: as mesmas 8 lições de Natal, os artesanatos, os caça-palavras, as cruzadinhas e o roteiro de teatrinho. Nada foi tirado. O reembolso em até 7 dias também vale aqui.

[check: confirmar o preço de R$17 antes de publicar, seguindo o modelo de downsell do Caderno do Casal. Alternativa: criar uma versão só com as lições e definir o preço.]

- As 8 lições de Natal para a classe infantil
- Artesanatos e roteiro de teatrinho
- Caça-palavras e cruzadinhas bíblicas
- Referências bíblicas e paráfrases, sem citação literal de versões
- Arquivo digital para imprimir

[cta_yes] Sim, quero o Natal na EBD por R$17

[cta_no] Não, quero ficar só com o que já comprei.

## /afiliados

**Indique o Kit Natal na Escola e receba 50% de comissão**



Se você fala com professoras, famílias que fazem homeschool ou educadores, o Kit Natal na Escola pode ser uma indicação útil para o seu público no fim do ano.

Você recebe 50% de comissão sobre o produto principal (Kit Natal na Escola, R$27) nas vendas feitas pelo seu link. O adicional do checkout e as ofertas depois da compra não entram na comissão [check: confirmar essa regra, se a comissão é calculada antes ou depois das taxas da plataforma e o prazo de pagamento na EscalePay].

A gente não promete renda: quanto você vende depende do seu público e do seu trabalho. O que oferecemos é um produto honesto, uma página clara e materiais de divulgação (imagens do kit e textos-base).

- Comissão de 50% sobre o Kit Natal na Escola
- Proibido prometer ganhos, resultados ou renda, para compradores ou outros afiliados
- Proibido prometer que o kit melhora notas, aprendizado ou comportamento das crianças
- Proibido spam: nada de mensagens em massa, grupos sem permissão ou comentários repetidos
- Proibido escassez falsa, contador fictício, depoimento inventado ou “mais vendido”
- Anúncios devem ser direcionados a adultos, nunca a crianças
- Não use fotos de crianças nem personagens de marcas registradas nos seus criativos
- Não diga que o kit é religioso: ele é laico
- Quem descumprir as regras pode ter a afiliação cancelada [check: termos da plataforma]

[cta] Quero ser afiliado

## Cadastro na EscalePay / Hotmart

**EscalePay:** Kit Natal na Escola: 100+ Atividades para Imprimir

Mais de 100 atividades de Natal laicas para Educação Infantil e Fundamental I, em PDF para imprimir. Inclui traçado, ligue os pontos, labirintos, colorir por números, caça-palavras, cruzadinhas, 10 historinhas com perguntas de interpretação, produção de texto, matemática natalina, sudoku infantil, calendário do Advento de 24 dias (contagem regressiva, sem conteúdo religioso), certificados e gabaritos. Para professoras e professores, reforço escolar e homeschool. Produto digital: acesso após a confirmação do pagamento por Pix ou cartão. Licença individual para uso com a sua turma; revenda proibida. Reembolso em até 7 dias.

**Hotmart:** Kit Natal na Escola: 100+ Atividades de Natal para Imprimir (com Gabarito)

Material digital em PDF com mais de 100 atividades natalinas sem conteúdo religioso, para usar em escolas públicas e particulares, no reforço ou no homeschool. Traz atividades de coordenação motora (traçado, ligue os pontos), raciocínio (labirintos, sudoku infantil, matemática natalina), leitura e escrita (caça-palavras, cruzadinhas, 10 historinhas com interpretação, propostas de produção de texto), além de calendário do Advento de 24 dias em formato de contagem regressiva, certificados de encerramento e gabaritos. Pensado para Educação Infantil e Fundamental I. Licença individual de uso. Reembolso em até 7 dias.

Palavras-chave: atividades de natal para imprimir, atividades natalinas educação infantil, atividades de natal fundamental 1, caça-palavras de natal, kit natal escola, atividades de natal com gabarito, atividades de natal laicas, calendário do advento para imprimir, matemática natalina, atividades de fim de ano escola, certificado de encerramento do ano letivo


## Mensagens de acompanhamento

### 1. Acesso ao kit (email)

```
Assunto: Seu Kit Natal na Escola chegou

Olá, [primeiro nome]!

Obrigado pela compra. Aqui está o seu acesso ao Kit Natal na Escola: [link de acesso].

Uma dica rápida: salve o PDF no Google Drive ou no computador logo agora, para não depender deste e-mail depois.

Se tiver qualquer problema para baixar, responda esta mensagem ou fale pelo [contato].

Bom planejamento!
Equipe [Nome da marca]

[Nome] | [NUIT/identificação] | [contato]
```

### 2. Dica do dia 2 (email)

```
Assunto: Um jeito simples de montar a sua semana de Natal

Olá, [primeiro nome]!

Uma forma prática de usar o kit: separe, para cada dia, uma atividade de coordenação ou raciocínio (labirinto, ligue os pontos, sudoku) e uma de leitura ou escrita (historinha com interpretação, cruzadinha, produção de texto).

Outra ideia: monte um “cantinho do Natal” com algumas folhas extras para quem termina antes. Guardando os gabaritos numa pasta à parte, a correção fica mais rápida.

E o calendário do Advento de 24 dias pode ser adaptado ao calendário da sua escola: comece quando fizer sentido para a sua turma.

Equipe [Nome da marca]

Não quer mais receber nossos e-mails? [link para descadastrar]
```

### 3. Lembrete do kit da EBD (email (só para quem consentiu receber marketing))

```
Assunto: Para quem também dá aula na EBD

Olá, [primeiro nome]!

Se além da escola você dá aula na Escola Bíblica Dominical, talvez goste de saber que existe o Natal na EBD: Kit de Atividades Bíblicas.

São 8 lições de Natal, artesanatos, caça-palavras, cruzadinhas e um roteiro de teatrinho, com referências bíblicas e paráfrases. Custa R$27, com reembolso em até 7 dias: [link].

Se não for o seu caso, é só ignorar este e-mail.

Equipe [Nome da marca]

[link para descadastrar]
```

### 4. Pedido de avaliação (email ou WhatsApp (só com consentimento))

```
Olá, [primeiro nome]! Aqui é da [Nome da marca].

Você já conseguiu usar o Kit Natal na Escola com a turma? A sua opinião sincera ajuda a gente a melhorar o material e pode ajudar outras professoras a decidir.

Se quiser, responda contando o que funcionou e o que poderia ser melhor. Se você autorizar, podemos publicar o seu comentário só com o primeiro nome (ou iniciais) e a cidade. Sem fotos de crianças, por favor.

Obrigado!

Para não receber mais mensagens, responda SAIR.
```

### 5. Conheça as outras coleções (email (só para quem consentiu receber marketing))

```
Assunto: Para o seu 2027 começar organizado

Olá, [primeiro nome]!

Além do Kit Natal na Escola, a [Nome da marca] tem mais duas coleções para imprimir:

Planner Financeiro 2027 (R$27): calendário de 2027 com feriados do Brasil, metas, orçamento mensal, contas, dívidas, reserva de emergência e revisões mensais. Material educativo para organizar as suas finanças, sem promessa de resultado.

Caderno do Casal: 52 Encontros para Reconectar (R$27): perguntas, desafios semanais e ideias de encontros de baixo custo para fazer a dois.

E o Mega Kit 2027, com os 9 produtos das três coleções: R$67 de 27 a 30 de novembro de 2026, e depois R$97. Atenção: ele inclui o Kit Natal na Escola, que você já tem. [check: confirmar disponibilidade e preço do Mega Kit antes de 27 de novembro]

Ver as coleções: [link]

Equipe [Nome da marca]

[link para descadastrar]
```

### 6. Checkout não finalizado (só com consentimento) (email ou WhatsApp (só se a pessoa autorizou contato no checkout))

```
Olá, [primeiro nome]! Aqui é da [Nome da marca].

Vimos que você começou a compra do Kit Natal na Escola, mas o pagamento não foi concluído. Se teve alguma dificuldade com o Pix ou o cartão, ou ficou alguma dúvida sobre o kit, é só responder esta mensagem.

Se ainda quiser, o link é este: [link do checkout]. O preço continua R$27, com reembolso em até 7 dias.

Se preferir não receber mais mensagens, responda SAIR e não falaremos mais sobre isso.
```


## Avisos legais

- Produto digital em PDF para imprimir. Nenhum item físico é enviado.
- Material educativo de apoio. Não garantimos resultados de aprendizagem, notas ou comportamento: isso depende da turma, do planejamento e da mediação de cada educador.
- O Kit Natal na Escola é laico. O Natal na EBD é um produto separado, opcional, com referências bíblicas e paráfrases.
- Você pode pedir reembolso em até 7 dias após a compra, conforme o art. 49 do Código de Defesa do Consumidor, pelo [contato].
- Licença individual de uso com a sua turma, seus alunos ou sua família. É proibido revender, distribuir ou publicar o conteúdo.
- Não coletamos dados de crianças. Os certificados são preenchidos à mão, depois de impressos.
- Ilustrações próprias ou licenciadas. Não usamos personagens protegidos por direitos autorais ou marcas registradas.
- Os depoimentos publicados são de compradores reais, com autorização. Não usamos depoimentos inventados.
- Seus dados são tratados conforme a nossa Política de Privacidade (LGPD). Mensagens de marketing só com o seu consentimento, e você pode cancelar quando quiser.
- Vendido por [Nome], [NUIT/identificação], [contato]. Pagamento processado por [EscalePay — check].
- Nota interna (não publicar): a soma dos 9 produtos dá R$207,70, mas o catálogo diz R$207,60 como âncora do Mega Kit. Confirme antes de usar essa âncora em qualquer página.
- Nota interna (não publicar): antes de divulgar, faça uma compra-teste real paga por Pix por um comprador brasileiro e outra por cartão; confirme moeda exibida (R$), entrega do arquivo, funcionamento do one-click e prazo do repasse. Saque com frequência e não mantenha saldo alto na plataforma.
- Nota interna (não publicar): o catálogo não define downsell para o Natal na EBD. O preço de R$17 na página de downsell é proposta e precisa ser confirmado.