# 1 Caderno do Casal: textos de venda (PT-BR, revisados)

**SEO:** Caderno do Casal: 52 Encontros para Reconectar | PDF para Imprimir por R$27

**Meta:** 52 encontros guiados para casais, um por semana: 260 perguntas, desafios e ideias de encontro de baixo custo. PDF para imprimir ou usar no tablet. Garantia de 7 dias.


## 01 · Hero

**52 encontros prontos para vocês conversarem de verdade, uma semana de cada vez**

Quando a semana vira só logística, o Caderno do Casal entrega um encontro guiado para cada semana do ano: 5 perguntas, um desafio e uma ideia de encontro que cabe no bolso. PDF para imprimir ou usar no tablet.

Trabalho, contas, filhos, celular. Em muitas casas, a conversa a dois vai virando só logística: quem paga o boleto, quem busca as crianças, o que tem para o jantar.

O Caderno do Casal dá a vocês um motivo simples para parar, sentar juntos e se olhar de novo: uma vez por semana, com tudo pronto. Vocês só precisam abrir a página e começar.

R$27, pagamento único por Pix ou cartão, com acesso logo após a confirmação do pagamento e garantia de 7 dias.

- 52 encontros divididos em 4 temporadas: Conhecer, Sonhar, Cuidar e Crescer
- 5 perguntas por encontro, começando leve e aprofundando aos poucos
- Toda semana: um desafio para fazer ao longo dos dias e uma ideia de encontro de baixo custo
- Espaço para vocês escreverem as respostas e guardarem a história de vocês

[BOTÃO] Quero o Caderno do Casal por R$27

_Design (para o Lovable): Two-column on desktop (copy left, mockup right); on mobile stack headline > mockup > bullets > CTA. Slot [MOCKUP_HERO]: printed Caderno do Casal open on a wooden table, two coffee mugs, warm evening light, only hands visible (faceless brand, no faces). Warm palette: terracotta, cream, deep green. Price R$27 clearly next to the CTA, with Pix and card badges underneath (only methods confirmed by a real test purchase). Before publishing, confirm with a real test purchase from a Brazilian buyer that the EscalePay checkout shows and charges R$27 in BRL with no extra fee added on top (check: currency display and FX are not verified). Full-width CTA on mobile; add a sticky bottom CTA bar after the first scroll. No stock photos of identifiable couples; if any AI-generated people appear, keep faces out of frame. Do not reuse the old question-style headline (“Vocês ainda conversam de verdade...?”) in Meta ads: questions that imply the viewer’s relationship situation are a personal-attributes risk._

## 02 · Problema

**O amor raramente some de um dia para o outro. Muitas vezes, é a conversa que vai ficando para depois.**

Talvez você reconheça alguma destas cenas.

Vocês dividem a casa, a cama, as contas e o cansaço. Mas a última conversa longa foi sobre quem paga o boleto, o que tem para o jantar ou quem busca as crianças.

À noite, cada um fica rolando o feed no próprio celular. O sábado vira faxina, mercado e sono atrasado. Quando finalmente sobra um tempinho, bate aquela dúvida: “sobre o que a gente vai falar?”

Muitas vezes, não é falta de amor. É falta de espaço, de tempo e de um empurrãozinho para começar.

- Vocês conversam o dia todo, mas quase sempre sobre tarefas
- Sair a dois parece caro ou complicado demais para a rotina de vocês
- Bate saudade da época em que vocês estavam se descobrindo
- O “depois a gente conversa” nunca chega

[BOTÃO] Quero voltar a conversar de verdade

_Design (para o Lovable): Single column, generous whitespace, cream background. Render bullets as short 'scene' cards with subtle line icons (phone, receipt, calendar, clock). Optional slot [MOCKUP_PROBLEM]: two phones glowing on a dark sofa at night, hands only, no faces. Emphasis on the headline; no bold in the body. Secondary (outline) CTA button that scrolls to the offer. Landing-page use only: do not turn these scenes into ad headlines addressed to 'você' (Meta personal-attributes policy)._

## 03 · História da marca

**Por que a gente criou o Caderno do Casal**

Sem fórmula mágica: só um jeito prático de colocar a relação de vocês na agenda.

Aqui no [Nome da marca], a gente acredita numa coisa simples: conexão não acontece só nos grandes momentos. Ela vai sendo construída nas conversas pequenas, repetidas, semana após semana.

O problema é que, na correria, quase ninguém tem energia para inventar pergunta boa, planejar encontro e ainda lembrar de fazer isso toda semana. Então a gente fez essa parte por vocês.

Reunimos 260 perguntas, 52 desafios e 52 ideias de encontro em um caderno organizado por temporadas, para vocês abrirem e começarem. Sem cobrança, sem certo ou errado. Se uma semana não der, vocês retomam na próxima.

A gente não promete salvar casamento nenhum. Promete um caderno bem feito, que facilita a parte mais difícil: começar a conversa.

- Pequeno e frequente vale mais do que perfeito e raro
- Uma boa pergunta abre assuntos que a conversa da rotina não abre
- Encontro não precisa ser caro para ser especial

[BOTÃO] Quero começar nossos encontros

_Design (para o Lovable): Brand-voice section: no founder photo, no invented biography, no personal story. Use the [Nome da marca] logo mark or a simple line illustration. Style the last paragraph as a pull quote. Show the three principles as small cards. Slot [MOCKUP_STORY]: flat-lay of several notebook pages with a pen and a generic handwritten note (no real names)._

## 04 · Solução

**Um encontro por semana. Tudo pronto. Vocês só precisam aparecer.**

O Caderno do Casal ajuda a transformar o “a gente precisa conversar mais” em um compromisso marcado na agenda de vocês.

Cada semana tem o seu encontro: 5 perguntas para conversar, um desafio para fazer ao longo dos dias e uma ideia de encontro de baixo custo, para fazer em casa ou pertinho dela.

Vocês escolhem o dia e o tempo. Dá para fazer em meia hora no sofá depois que as crianças dormem, num café de domingo ou até por chamada de vídeo, se estiverem morando longe.

As perguntas seguem uma ordem pensada: começam mais leves e vão aprofundando ao longo das 4 temporadas. Assim ninguém se sente pressionado logo no primeiro encontro.

- Sem planejamento: abram o encontro da semana e comecem
- Sem gastar muito: as ideias de encontro são de baixo custo
- Sem pressão: pularam uma semana? É só seguir de onde pararam
- Com memória: as respostas escritas viram um registro do ano de vocês

[BOTÃO] Quero o Caderno do Casal

_Design (para o Lovable): Image-left/text-right layout. Slot [MOCKUP_SOLUTION]: one weekly encounter spread with 4 labelled callouts: 'Perguntas', 'Desafio da semana', 'Ideia de encontro', 'Espaço para escrever'. Bullets as a 2x2 icon-tile grid on desktop, single column on mobile._

## 05 · O que tem dentro

**O que tem dentro do Caderno do Casal**

52 encontros em 4 temporadas, com 13 encontros cada.

Temporada 1, Conhecer (encontros 1 a 13). Para redescobrir quem está do seu lado hoje: histórias, gostos e memórias que talvez nunca tenham sido contadas. Exemplo de pergunta: “Qual lembrança da sua infância ainda te faz sorrir?”

Temporada 2, Sonhar (encontros 14 a 26). Para falar de planos, vontades e do futuro que vocês querem construir juntos. Exemplo: “Se a gente pudesse passar um mês em qualquer lugar, para onde iria e o que faria lá?”

Temporada 3, Cuidar (encontros 27 a 39). Para conversar sobre o que faz cada um se sentir amado, ouvido e respeitado. Exemplo: “O que eu faço no dia a dia que faz você se sentir cuidado(a)?”

Temporada 4, Crescer (encontros 40 a 52). Para olhar o caminho, reconhecer o que vocês já atravessaram e decidir juntos o próximo passo. Exemplo: “Qual fase difícil a gente superou junto e o que ela ensinou para nós?”

Em cada um dos 52 encontros vocês encontram 5 perguntas, 1 desafio da semana (como deixar um bilhete escondido ou assumir uma tarefa que o outro sempre faz sozinho), 1 ideia de encontro de baixo custo (como piquenique na sala, noite de jogos ou cozinhar uma receita nova juntos) e espaço para escrever.

- 52 encontros semanais em 4 temporadas
- 260 perguntas para conversar (5 por encontro)
- 52 desafios da semana
- 52 ideias de encontro de baixo custo
- Espaço para escrever em cada encontro
- Arquivo digital em PDF: imprima em casa ou numa gráfica, ou use no tablet

[BOTÃO] Quero receber os 52 encontros

_Design (para o Lovable): Four season cards (Conhecer, Sonhar, Cuidar, Crescer), each with its own accent color and a mini mockup slot [MOCKUP_SEASON_1] to [MOCKUP_SEASON_4] showing that season's opening page. Season names styled as card titles (keep body free of bold). Sample questions in italic quote style. IMPORTANT: every sample question, challenge and date idea shown here must exist word-for-word in the final PDF; replace them if the product differs. Add slot [FLIPTHROUGH_VIDEO] for a short silent flip-through of the PDF pages. Only state page size or page count after confirming them in the final file (check)._

## 06 · Prévia do complemento (order bump)

**Quer conversar além do encontro da semana? Conheça os 100 Cartões de Perguntas para Casais**

Complemento opcional de R$12,90, que você pode adicionar na página de pagamento.

O Caderno do Casal organiza um encontro por semana. Os 100 Cartões são para todos os outros momentos: a fila do restaurante, a viagem de carro, o jantar de domingo, aquela noite em que ninguém está com sono.

São 100 cartões para imprimir e recortar, em 5 categorias com 20 cartões cada. Embaralhou, tirou um, conversou.

É totalmente opcional. O Caderno do Casal funciona completo sozinho.

- 100 perguntas em cartões para imprimir e recortar
- 5 categorias, com 20 cartões em cada
- Práticos para viagens, jantares ou para completar um presente
- Adicionados no checkout por R$12,90; se você não marcar, nada é cobrado a mais

[BOTÃO] Quero começar pelo Caderno do Casal

_Design (para o Lovable): Slot [MOCKUP_BUMP_CARDS]: printed question cards fanned out on a table next to scissors, hands only. Add a small 'Opcional' tag and show the price R$12,90 clearly. Do NOT call it a free bonus. Show the 5 real category names as chips once the product is final (suggestion: Divertidas, Memórias, Sonhos, Sentimentos, Futuro a dois). Keep this section visually lighter than the main offer. Confirm in a test purchase that the bump checkbox is unchecked by default (pre-checked bumps are a consumer-protection risk)._

## 07 · Como funciona

**Como funciona**

Três passos, e o primeiro encontro pode ser hoje à noite.

1. Compre com Pix ou cartão. Você confere o valor final antes de confirmar o pagamento.

2. Receba o acesso por e-mail. Assim que o pagamento é confirmado, o link para baixar o PDF chega no seu e-mail. No Pix, a confirmação costuma sair em instantes.

3. Imprima ou use na tela. Imprima em casa ou numa gráfica, ou abra no tablet com um app de anotações. Escolham o dia e comecem pelo encontro 1.

- Compre com Pix ou cartão e confira o valor final antes de pagar
- Receba o acesso por e-mail logo após a confirmação do pagamento
- Imprima ou use no tablet e comece pelo encontro 1

[BOTÃO] Quero começar hoje

_Design (para o Lovable): Three horizontal steps with numbered circles; stack vertically on mobile. Pix and card logos next to step 1, showing only methods confirmed by a real test purchase on the checkout. Time the access e-mail during the test purchase; if delivery is not near-instant, adjust step 2 wording. Slot [MOCKUP_DEVICES]: the PDF displayed on a phone, a tablet and as printed pages side by side._

## 08 · Para quem é

**O Caderno do Casal é para você se...**

Não importa se vocês estão juntos há 6 meses ou há 15 anos.

Serve para quem está namorando e quer se conhecer melhor, para quem está noivo e quer chegar ao casamento conversando sobre o que importa, e para quem é casado há anos e sente que a rotina engoliu os momentos a dois.

E também pode ser um presente de Natal feito para ser usado, e não esquecido na gaveta: imprima, coloque numa pasta bonita ou mande encadernar, e entregue com um bilhete marcando a data do primeiro encontro.

- Vocês estão namorando, noivos ou casados e querem mais momentos de conexão
- A rotina com trabalho e filhos deixou pouco tempo a dois
- Você quer encontros especiais sem gastar muito
- Vocês moram longe e querem algo para fazer juntos por chamada de vídeo
- Você está procurando um presente de Natal, de aniversário de namoro ou de casamento com significado
- Vocês gostam de escrever e guardar memórias

[BOTÃO] Esse caderno é para nós

_Design (para o Lovable): Checklist style with soft green check icons. Slot [MOCKUP_GIFT]: printed notebook in a kraft folder tied with a ribbon next to a small Christmas ornament, hands only. Highlight the gift paragraph with a soft background band during Oct-Dec; easy to remove after the season._

## 09 · Para quem não é

**Para quem o Caderno do Casal não é**

A gente prefere que você compre sabendo exatamente o que está levando.

O Caderno do Casal é uma ferramenta de conversa e convivência. Ele não é terapia, não resolve sozinho uma crise séria e não substitui acompanhamento profissional.

Se vocês estão passando por um momento muito difícil, procurem um(a) psicólogo(a) ou terapeuta de casal. Se existe qualquer tipo de violência no relacionamento, priorize a sua segurança e procure ajuda especializada (no Brasil, Ligue 180; em emergência, 190).

- Você quer um caderno físico entregue em casa (este é um arquivo digital em PDF)
- Você procura terapia ou uma solução garantida para uma crise
- Você pretende obrigar o parceiro ou a parceira a participar
- Vocês não pretendem reservar nem meia hora por semana para isso

[BOTÃO] Entendi. Quero ver a oferta

_Design (para o Lovable): Calm, neutral styling; use simple dashes instead of red X icons. Keep this section visible: it builds trust and reduces refunds. Verify the 'Ligue 180' and '190' references before publishing (check)._

## 10 · Oferta

**Tudo o que você recebe por R$27**

Pagamento único, por Pix ou cartão. Sem mensalidade.

São 52 encontros por R$27. Fazendo a conta, dá cerca de R$0,52 por encontro.

Você baixa o PDF uma vez e pode imprimir quantas vezes quiser para uso pessoal, inclusive no ano que vem, se quiserem repetir as perguntas e comparar as respostas.

- Caderno do Casal completo: 52 encontros em 4 temporadas
- 260 perguntas para conversar
- 52 desafios da semana
- 52 ideias de encontro de baixo custo
- Espaço para escrever em cada encontro
- Acesso ao PDF por e-mail logo após a confirmação do pagamento
- Garantia de 7 dias
- Opcional no checkout: 100 Cartões de Perguntas para Casais por R$12,90

[BOTÃO] Quero o Caderno do Casal por R$27

_Design (para o Lovable): Boxed offer card with one large price: R$27. No strikethrough 'de/por' price and no invented 'valor total'; the only anchor is the honest R$0,52-per-encounter math (27 / 52 = 0,519). Slot [MOCKUP_OFFER]: full product mockup (cover + 3 inner pages + phone screen). Pix and card badges under the CTA. Mention instalments only if the live checkout actually offers them (check via test purchase). Confirm the checkout charges in BRL (check)._

## 11 · Garantia

**Garantia de 7 dias, sem complicação**

O seu direito de arrependimento, previsto no Código de Defesa do Consumidor.

Você tem 7 dias a partir da compra para conhecer o Caderno do Casal com calma. Se sentir que não é para vocês, é só pedir o reembolso por [contato] ou pela plataforma de pagamento dentro desse prazo, e devolvemos 100% do valor pago.

Não precisa explicar o motivo. Esse direito está no artigo 49 do Código de Defesa do Consumidor para compras feitas pela internet, e a gente respeita sem enrolação. A garantia vale também para os complementos que você adicionar ao pedido.

- Prazo: 7 dias a partir da compra
- Reembolso de 100% do valor pago
- Pedido por [contato] ou pela plataforma de pagamento
- Vale para o Caderno e para cada complemento comprado

[BOTÃO] Quero experimentar com garantia

_Design (para o Lovable): Generic seal-style badge with '7 dias' (not an official government seal). Plain-language text, no fine print. Before launch, test the refund flow on EscalePay (Pix and card) and note how long the money takes to return; only state a refund timeline after testing (check). Make sure [contato] is a monitored email/WhatsApp. Internal target: answer refund requests within 48h._

## 12 · Depoimentos

**O que dizem os casais que já usaram**

Relatos reais de quem comprou, publicados com autorização.

[Depoimento real do primeiro cliente]

[Depoimento real do segundo cliente]

[Depoimento real do terceiro cliente]

- Instrução: publique somente depoimentos reais, enviados por clientes, com autorização por escrito.
- Instrução: use primeiro nome e cidade/estado apenas se a pessoa autorizar.
- Instrução: não altere o sentido do texto, não crie depoimentos e não use prints montados.
- Instrução: prefira relatos da experiência de uso; evite frases que prometam resultado (ex.: “salvou meu casamento”).
- Instrução: enquanto não houver depoimentos reais, mantenha esta seção oculta.

[BOTÃO] Quero viver nossos encontros

_Design (para o Lovable): HIDE this section until at least 2-3 real testimonials exist. Text cards with first name + city only; no photos unless the customer sends one and authorizes it. Never use AI-generated faces or stock photos as 'customers'. Store the original messages and the written permission in a private folder._

## 13 · Introdução ao FAQ

**Ficou alguma dúvida?**

Reunimos as perguntas mais comuns antes da compra.

Se a sua dúvida não estiver aqui, fale com a gente em [contato]. Respondemos em português, em até [prazo de resposta].


_Design (para o Lovable): Accordion FAQ directly below this intro, using the FAQ list. First item open by default. Keep a small CTA link back to the offer after the last question. Fill [prazo de resposta] only with a deadline you can actually keep (e.g., 48h)._

## 14 · Chamada final

**A próxima semana vai passar de qualquer jeito. Que ela tenha um encontro de vocês.**

Caderno do Casal: 52 Encontros para Reconectar, por R$27.

Você pode continuar esperando sobrar tempo para conversar. Ou pode deixar esse tempo marcado, com as perguntas prontas e uma ideia de encontro esperando na página.

São R$27, pagamento único por Pix ou cartão, acesso por e-mail logo após a confirmação e 7 dias de garantia. O primeiro encontro pode ser hoje à noite.

- 52 encontros guiados em 4 temporadas
- 260 perguntas, 52 desafios e 52 ideias de encontro de baixo custo
- PDF para imprimir ou usar no tablet
- Garantia de 7 dias

[BOTÃO] Quero o Caderno do Casal por R$27

_Design (para o Lovable): Full-width warm background (terracotta to cream gradient). Slot [MOCKUP_FINAL]: notebook open between two hands holding mugs across a table, evening light, no faces. Large CTA, repeat payment badges and the 7-day guarantee badge._

## 15 · Rodapé

**[Nome da marca]**

Produtos digitais para casais, famílias e educadores.

Vendido por: [Nome]
Identificação: [NUIT/identificação]
Endereço: [endereço completo]
Contato: [contato]

Pagamentos processados por [plataforma de pagamento]. O valor final e as formas de pagamento aparecem na página de pagamento antes da confirmação. Produto digital entregue por e-mail em formato PDF; nenhum item físico é enviado. Imagens meramente ilustrativas.

Material educativo e de entretenimento para casais. Não substitui acompanhamento psicológico ou terapia. A experiência depende de cada casal.

© 2026 [Nome da marca]. Todos os direitos reservados.

- Política de Privacidade
- Termos de Uso
- Política de Reembolso (7 dias)
- Contato

_Design (para o Lovable): Small but readable text with sufficient contrast. Link to Privacy Policy (LGPD, in Portuguese), Terms of Use and Refund Policy pages. Seller identification is required for online sales to Brazilian consumers (Decreto 7.962/2013): fill every placeholder and confirm the exact required fields, including address (check). Add a cookie/consent banner if any tracking pixel is installed._

## FAQ

**O Caderno do Casal é um produto físico?**

Não. É um arquivo digital em PDF. Você recebe o link para baixar por e-mail e pode imprimir em casa, numa gráfica ou usar no tablet. Nenhum item é enviado pelos Correios.

**Como e quando eu recebo o acesso?**

Logo após a confirmação do pagamento, o link chega no e-mail que você informou na compra. No Pix, a confirmação costuma sair em instantes. Se não encontrar, confira as pastas de spam e promoções ou fale com a gente em [contato].

**Preciso imprimir?**

Não é obrigatório. Dá para usar no celular ou no tablet. Mas, para aproveitar o espaço de escrever, o ideal é imprimir ou usar um app de anotações em PDF no tablet.

**Serve para quem está namorando ou noivo?**

Sim. O caderno foi pensado para namorados, noivos e casados. As primeiras temporadas são mais leves e funcionam bem para quem está se conhecendo; as últimas aprofundam conversas sobre cuidado e futuro.

**E se o meu parceiro ou a minha parceira não curtir esse tipo de coisa?**

Comece pelo encontro 1, que é leve, e faça o convite sem pressão: “bora testar uma vez?”. Ninguém precisa responder tudo; vale pular uma pergunta. E, se não fizer sentido para vocês, você tem 7 dias para pedir o reembolso.

**Quanto tempo leva cada encontro?**

Vocês decidem. Dá para fazer em cerca de meia hora e, se a conversa render, ela pode virar uma noite inteira. O desafio da semana acontece ao longo dos dias, sem tempo marcado.

**Os encontros vão me fazer gastar dinheiro?**

A ideia é justamente o contrário. As ideias de encontro são de baixo custo, e muitas dá para fazer em casa, como piquenique na sala, noite de jogos ou cozinhar algo novo juntos.

**É um material religioso?**

Não. O Caderno do Casal é para qualquer casal, de qualquer crença. Para casais cristãos, existe um complemento separado e opcional, o Devocional do Casal, oferecido depois da compra.

**Posso dar de presente de Natal?**

Pode, e é uma ótima ideia de presente. Você compra, imprime e entrega numa pasta ou encadernado, com um bilhete marcando o primeiro encontro. Também pode encaminhar o arquivo para o casal presenteado. O uso é pessoal: pedimos que não revenda nem compartilhe o arquivo publicamente.

**Quais são as formas de pagamento?**

Pix ou cartão. As opções exatas, incluindo parcelamento se estiver disponível, e o valor final aparecem na página de pagamento antes de você confirmar.

**Quem está vendendo o Caderno do Casal?**

O Caderno do Casal é um produto da [Nome da marca]. Os dados completos do vendedor (nome, identificação, endereço e contato) estão no rodapé desta página, e o pagamento é processado por [plataforma de pagamento].

**E se eu me arrepender da compra?**

Você tem 7 dias a partir da compra para pedir o reembolso de 100% do valor, sem precisar explicar o motivo, conforme o artigo 49 do Código de Defesa do Consumidor. É só falar com a gente em [contato] ou pela plataforma de pagamento.

**O caderno substitui terapia de casal?**

Não. É uma ferramenta de conversa e convivência, educativa e de entretenimento. Se vocês estão passando por uma crise séria, procurem um(a) psicólogo(a) ou terapeuta de casal. Em caso de violência, procure ajuda especializada (no Brasil, Ligue 180; em emergência, 190).


## Checkout: order bump

**Sim! Quero adicionar os 100 Cartões de Perguntas para Casais por R$12,90**

Leve também 100 cartões de perguntas para imprimir e recortar, em 5 categorias com 20 cartões cada, para conversar além do encontro da semana: no carro, no jantar, antes de dormir. Combinam com o Caderno do Casal e ajudam a completar um presente. É opcional: marque a caixa para adicionar. Se não marcar, nada é cobrado a mais.


## /obrigado

**Compra confirmada! Seu Caderno do Casal está a caminho do seu e-mail**



Obrigado pela confiança. O link para baixar o seu PDF é enviado para o e-mail que você usou na compra assim que o pagamento é confirmado. Se você adicionou os 100 Cartões de Perguntas ou o Devocional do Casal, eles chegam no mesmo e-mail ou em um e-mail separado.

Agora falta só uma coisa: marcar o primeiro encontro. Não precisa ser perfeito, só precisa acontecer.

- Abra o e-mail de acesso (se não estiver na caixa de entrada, confira spam e promoções).
- Baixe o PDF e salve no celular, no computador ou no Google Drive para não perder.
- Imprima em casa ou numa gráfica, ou abra no tablet com um app de anotações.
- Combine com a pessoa amada o dia e o horário fixo dos encontros e marquem na agenda.
- Comecem pelo encontro 1, da temporada Conhecer, mesmo que vocês já se conheçam há anos.
- Algum problema com o acesso? Fale com a gente em [contato].

[upsell_teaser] Em breve: o Planner Financeiro 2027, para vocês organizarem também o dinheiro da casa juntos, e o Kit Natal na Escola, com mais de 100 atividades para imprimir. E de 27 a 30 de novembro de 2026, o Mega Kit 2027 reúne os 9 produtos da loja (incluindo o Caderno do Casal) por R$67; depois do dia 30, ele passa a custar R$97. Quer ser avisado(a)? [Entre no nosso canal de WhatsApp/Telegram] (só entra quem quiser e dá para sair quando quiser).

## /oferta-especial (upsell)

**Antes de você ir: que tal incluir a fé nesses encontros?**

Devocional do Casal: 30 Dias Juntos com Deus, por R$27, que você pode adicionar ao seu pedido agora.

Para muitos casais cristãos, se reconectar também passa por orar juntos, ler a Palavra juntos e conversar sobre fé. Só que, na correria, o devocional a dois costuma ser a primeira coisa a ficar para depois.

O Devocional do Casal foi feito para caber na rotina: 30 dias de momentos curtos, para vocês fazerem lado a lado, de manhã ou antes de dormir.

Cada dia indica uma passagem bíblica para vocês lerem na Bíblia de vocês, na tradução que preferirem, e traz uma reflexão curta, uma pergunta para conversar a dois e uma sugestão de oração. Ele complementa o Caderno do Casal, mas também funciona sozinho.

É opcional. Se não fizer sentido para vocês agora, é só clicar em “Não, obrigado” e seguir para o seu acesso.

- 30 dias de devocional para fazer a dois
- Uma passagem bíblica indicada por dia, para ler na sua própria Bíblia
- Reflexão curta e uma pergunta para conversar juntos
- Sugestão de oração para o casal
- Espaço para anotações
- PDF para imprimir ou usar no tablet, enviado por e-mail
- Garantia de 7 dias também para este produto

[cta_yes] Sim, quero o Devocional do Casal por R$27

[cta_no] Não, obrigado. Quero ficar só com o meu Caderno do Casal.

## /segunda-chance (downsell)

**Tudo bem. E se o Devocional do Casal saísse por R$17?**

O mesmo devocional completo de 30 dias, por um valor menor.

Talvez R$27 não caiba no orçamento agora, e a gente entende.

Por isso, aqui vai uma alternativa: o mesmo Devocional do Casal: 30 Dias Juntos com Deus, completo, sem tirar nenhuma página, por R$17.

Se ainda assim não for o momento, sem problema nenhum. Clique em “Não, obrigado” e siga para o seu acesso: a compra do seu Caderno do Casal já está confirmada.

- Os mesmos 30 dias de devocional a dois
- Passagem bíblica indicada, reflexão, pergunta para conversar e oração em cada dia
- PDF para imprimir ou usar no tablet
- Garantia de 7 dias também para este produto

[cta_yes] Sim, quero o Devocional do Casal por R$17

[cta_no] Não, obrigado. Pode me levar ao meu acesso.

## /afiliados

**Indique o Caderno do Casal e receba 50% de comissão em cada venda feita pelo seu link**



O Caderno do Casal: 52 Encontros para Reconectar é um PDF com 52 encontros guiados para casais, cada um com 5 perguntas, um desafio da semana, uma ideia de encontro de baixo custo e espaço para escrever. O preço é R$27, pagamento por Pix ou cartão, com garantia de 7 dias.

É um produto fácil de mostrar em vídeo curto (flip-through das páginas, perguntas na tela, ideias de encontro) e combina com conteúdo de relacionamento, casamento, maternidade e paternidade, organização da rotina e presentes de Natal.

Você recebe 50% de comissão sobre cada venda do Caderno do Casal feita pelo seu link. A base de cálculo e o valor exato, já considerando as taxas da plataforma, aparecem no seu painel de afiliado. Regras de comissão para complementos e prazo de atribuição (cookie): [definir e informar aqui].

Disponibilizamos mockups, textos de apoio e ideias de roteiro em [link para materiais]. Ganhos dependem exclusivamente do seu trabalho de divulgação; não existe garantia de vendas nem de renda.

- Comissão: 50% sobre o Caderno do Casal (R$27), conforme as regras exibidas no painel
- Identifique sua divulgação como publicidade (ex.: #publi ou “link de afiliado”)
- Proibido prometer renda, lucro ou “dinheiro fácil” para recrutar outras pessoas
- Proibido prometer resultados no relacionamento (ex.: “vai salvar seu casamento”)
- Proibido spam: nada de grupos de WhatsApp ou Telegram sem permissão, mensagens em massa, comentários repetidos ou e-mails para listas compradas
- Proibido inventar depoimentos, números, rankings, escassez ou prazos falsos; não use “nº 1” nem “mais vendido”
- Não use o nome [Nome da marca] em anúncios de pesquisa nem crie perfis que se passem pela marca
- Sinalize conteúdo feito com IA conforme as regras de cada rede social e siga as políticas de anúncios da Meta e do TikTok
- Respeite a LGPD: não colete nem compartilhe dados de clientes
- O descumprimento das regras leva ao descredenciamento e ao cancelamento das comissões irregulares

[cta] Quero me afiliar ao Caderno do Casal

## Cadastro na EscalePay / Hotmart

**EscalePay:** Caderno do Casal: 52 Encontros para Reconectar (PDF para imprimir)

Caderno digital em PDF com 52 encontros guiados para casais, um para cada semana do ano, divididos em 4 temporadas: Conhecer, Sonhar, Cuidar e Crescer. Cada encontro traz 5 perguntas para conversar, um desafio da semana, uma ideia de encontro de baixo custo e espaço para escrever. Para namorados, noivos e casados que querem sair do automático, e também uma opção de presente de Natal com significado. Imprima ou use no tablet. Pagamento por Pix ou cartão, acesso por e-mail após a confirmação e garantia de 7 dias. Material educativo; não substitui terapia.

**Hotmart:** Caderno do Casal: 52 Encontros para Reconectar

Na correria do trabalho, das contas e dos filhos, a conversa a dois vai ficando para depois. O Caderno do Casal facilita a parte difícil: começar. São 52 encontros semanais em 4 temporadas (Conhecer, Sonhar, Cuidar e Crescer), com 260 perguntas, 52 desafios da semana, 52 ideias de encontro de baixo custo e espaço para escrever as respostas. Para namorados, noivos e casados. PDF para imprimir ou usar no tablet. Material educativo, não substitui terapia. Garantia de 7 dias.

Palavras-chave: caderno do casal, perguntas para casais, encontros para casais, dinâmica para casal, presente de natal para casal, presente para namorado, presente para namorada, ideias de encontro barato, conversa a dois, caderno para casais para imprimir


## Mensagens de acompanhamento

### 1. Acesso ao produto (E-mail (imediatamente após a compra))

```
Assunto: Seu Caderno do Casal chegou (link de acesso aqui dentro)

Olá, [primeiro nome]!

Obrigado pela compra. Aqui está o seu acesso ao Caderno do Casal: 52 Encontros para Reconectar:

[link de download]

Uma sugestão para começar bem: salve o PDF no celular ou no Google Drive, imprima (ou abra no tablet) e combine hoje mesmo o dia fixo dos encontros. Comecem pelo encontro 1, da temporada Conhecer.

Se você adicionou os 100 Cartões de Perguntas ou o Devocional do Casal, o acesso está neste e-mail ou em um e-mail separado.

Qualquer problema com o download, é só responder este e-mail ou falar com a gente em [contato].

Bons encontros,
Equipe [Nome da marca]
```

### 2. Dica do dia 2 (WhatsApp (somente para quem aceitou receber mensagens) ou e-mail)

```
Oi, [primeiro nome]! Aqui é da [Nome da marca], sobre o seu Caderno do Casal.

Uma dica rápida para o primeiro encontro: deixem os celulares em outro cômodo e combinem que não existe resposta certa. Vale dizer “não sei” e vale pular uma pergunta. O objetivo não é fazer uma prova, é conversar.

Se a semana estiver corrida, escolham só 2 das 5 perguntas. Melhor um encontro curto do que nenhum.

Para não receber mais mensagens por aqui, responda SAIR.
```

### 3. Lembrete do Devocional do Casal (E-mail (dia 3, apenas para quem não comprou o Devocional e aceitou receber ofertas))

```
Assunto: Para casais que querem incluir a fé nos encontros

Olá, [primeiro nome]!

Esperamos que o primeiro encontro do Caderno do Casal já tenha acontecido (ou esteja marcado).

Na sua compra, oferecemos o Devocional do Casal: 30 Dias Juntos com Deus. Se vocês são um casal cristão e gostariam de orar e refletir juntos, ele foi feito para caber na rotina: cada dia indica uma passagem bíblica para ler na Bíblia de vocês, com uma reflexão curta, uma pergunta para conversar e uma sugestão de oração.

O valor é R$27, com garantia de 7 dias: [link do Devocional]

Se não for para vocês, tudo certo: o Caderno do Casal já é completo sozinho.

Um abraço,
Equipe [Nome da marca]

Para não receber mais e-mails como este, [clique aqui].
```

### 4. Pedido de avaliação (E-mail (dia 10))

```
Assunto: Como estão os encontros de vocês?

Olá, [primeiro nome]!

Já faz alguns dias que você recebeu o Caderno do Casal, e a gente queria muito saber: como está sendo?

Pode responder este e-mail com a sua opinião sincera, inclusive o que não funcionou. É isso que nos ajuda a melhorar o material.

Se você gostou e permitir, podemos publicar o seu comentário na nossa página, com apenas o seu primeiro nome e cidade. Só publicamos se você disser claramente que autoriza, e você pode pedir a retirada a qualquer momento.

Obrigado por fazer parte disso,
Equipe [Nome da marca]

Para não receber mais e-mails como este, [clique aqui].
```

### 5. Cross-sell: outros produtos e Mega Kit 2027 (E-mail (quando cada produto entrar no ar; versão Mega Kit enviada de 27 a 30/11/2026), somente para quem aceitou receber ofertas)

```
Assunto: Para organizar 2027 em casa: planner financeiro e kit de Natal

Olá, [primeiro nome]!

Além do Caderno do Casal, preparamos mais dois materiais para imprimir:

Planner Financeiro 2027 (R$27): calendário 2027 com feriados brasileiros, metas, orçamento mensal, controle de contas e dívidas, reserva de emergência e revisões mensais, para vocês organizarem o dinheiro da casa juntos. Material educativo. [link]

Kit Natal na Escola: 100+ Atividades para Imprimir (R$27): atividades de Natal para crianças, como labirintos, ligue-os-pontos, caça-palavras, histórias com perguntas e calendário do Advento, com gabarito. [link]

E de 27 a 30 de novembro de 2026, o Mega Kit 2027: Tudo em Um reúne os 9 produtos da nossa loja por R$67. Somando os preços individuais, eles dariam R$207,70. Depois do dia 30, o Mega Kit passa a custar R$97. Importante: o Caderno do Casal também faz parte do kit, então avalie se ele vale a pena para você mesmo já tendo o Caderno. [link do Mega Kit]

Todos com garantia de 7 dias.

Equipe [Nome da marca]

Para não receber mais ofertas por e-mail, [clique aqui].
```

### 6. Lembrete de checkout abandonado (WhatsApp ou e-mail (1 a 2 horas após o abandono; envio único; somente se a pessoa deu consentimento para contato no checkout))

```
Oi, [primeiro nome]! Aqui é da [Nome da marca].

Vimos que você começou a compra do Caderno do Casal: 52 Encontros para Reconectar e não finalizou. Aconteceu algum problema com o Pix ou com o cartão?

Se ainda tiver interesse, o link é este: [link do checkout]. São R$27, com acesso por e-mail logo após a confirmação e garantia de 7 dias.

Se tiver alguma dúvida, é só responder esta mensagem. E se mudou de ideia, tudo bem: não vamos insistir.

Para não receber mais mensagens, responda SAIR.
```


## Avisos legais

- O Caderno do Casal, os 100 Cartões de Perguntas para Casais e o Devocional do Casal são materiais digitais (PDF) educativos e de entretenimento. Não são terapia e não substituem acompanhamento psicológico, médico ou terapia de casal.
- Não garantimos resultados: a experiência depende de cada casal e de como o material é usado.
- Direito de arrependimento: você pode pedir o reembolso de 100% do valor pago em até 7 dias a partir da compra, conforme o artigo 49 do Código de Defesa do Consumidor. Vale para cada produto comprado, inclusive complementos.
- Produto digital: nenhum item físico é enviado. O acesso é enviado por e-mail após a confirmação do pagamento. Imagens meramente ilustrativas.
- O valor final, as formas de pagamento e o eventual parcelamento são exibidos na página de pagamento antes da confirmação da compra.
- Preços promocionais, como o do Mega Kit 2027 (R$67 de 27 a 30/11/2026), valem somente nas datas informadas.
- Uso pessoal: é proibido revender, redistribuir ou compartilhar publicamente os arquivos.
- O Devocional do Casal indica referências bíblicas e traz reflexões próprias; a leitura dos textos bíblicos deve ser feita na Bíblia de sua preferência.
- Seus dados são tratados conforme a nossa Política de Privacidade, de acordo com a LGPD. Mensagens de marketing por e-mail ou WhatsApp só são enviadas com o seu consentimento, e você pode cancelar a qualquer momento.
- Programa de afiliados: comissões dependem exclusivamente das vendas realizadas; não há promessa de ganhos ou renda.
- Em situações de violência no relacionamento, procure ajuda especializada imediatamente (no Brasil, Ligue 180; em emergência, 190).