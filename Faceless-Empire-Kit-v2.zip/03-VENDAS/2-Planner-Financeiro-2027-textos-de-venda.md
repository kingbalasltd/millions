# 2 Planner Financeiro 2027: textos de venda (PT-BR, revisados)

**SEO:** Planner Financeiro 2027 para Imprimir | Orçamento, Contas e Dívidas

**Meta:** Planner Financeiro 2027 em PDF para imprimir: orçamento mensal, contas, dívidas, reserva de emergência e calendário com feriados. R$27, acesso imediato.


## 01 · Hero

**Organize o seu dinheiro de 2027 no papel, mês a mês**

Planner Financeiro 2027 para imprimir: cerca de 50 páginas para colocar orçamento, contas, dívidas, reserva de emergência e metas num lugar só. R$27, pagamento único, com acesso imediato após a aprovação do pagamento.

Sem planilha complicada e sem fórmula. Só papel, caneta e um roteiro claro, que cabe na sua rotina.

Você vai anotando um pouco por semana e, no fim de cada mês, usa a página de revisão para ver o que entrou, o que saiu e o que dá para ajustar no mês seguinte.

Comprando agora, antes da virada do ano, você ainda aproveita dezembro para listar suas contas e dívidas e chega em janeiro com tudo anotado e um plano para começar.

- Calendário 2027 com os feriados nacionais do Brasil
- 12 orçamentos mensais e 12 revisões mensais com dicas
- Controle de contas, dívidas, reserva de emergência e economias
- PDF para imprimir quantas vezes quiser, para uso pessoal e da sua família
- Pagamento único: sem mensalidade e sem assinatura

[BOTÃO] Quero meu Planner 2027 por R$27

_Design (para o Lovable): Two-column hero on desktop (copy left, image right), stacked on mobile with image below the headline. Image slot [MOCKUP_HERO]: printed planner cover 'Planner Financeiro 2027' on a light wooden desk with a pen, a coffee cup and a calculator, warm natural light; no people's faces, no real bank or card logos. Palette: calm green/teal for trust plus warm off-white background; avoid a red-heavy 'debt alarm' look. CTA button large, high contrast, repeated as a sticky bar on mobile. Under the button, small trust line: 'Pix ou cartão | Acesso imediato após a aprovação | Garantia de 7 dias'. Bold only the price in the subheadline. Do not add instalment text ('em até Xx') until confirmed in the test purchase._

## 02 · Problema

**O salário cai e, quando você vê, já foi**

Se alguma dessas cenas parece familiar, saiba que muita gente vive a mesma coisa.

Chega o dia 20 e a conta já está no limite. Você não comprou nada grande, mas o dinheiro foi sumindo em Pix pequenos, delivery, aplicativo de transporte, mercadinho.

A fatura do cartão chega maior do que você esperava. Um boleto ficou esquecido e voltou com juros. E quando entra um dinheiro extra, como o 13º, ele parece evaporar entre as contas de começo de ano: IPVA, IPTU, material escolar, matrícula.

Na maioria das vezes, o mais pesado nem é só a falta de dinheiro. É a sensação de não ter controle, de estar sempre apagando incêndio e nunca saber exatamente quanto deve, quanto gasta e quanto sobra.

- Você não sabe dizer, de cabeça, quanto gastou no mês passado
- A fatura do cartão sempre traz alguma surpresa
- Tem parcela, empréstimo ou cheque especial e não sabe o total que deve
- Já tentou se organizar, mas parou depois de algumas semanas
- O começo do ano chega e as contas de janeiro pegam você de surpresa

[BOTÃO] Quero organizar minhas contas

_Design (para o Lovable): Single column, generous line height, short paragraphs. Bullets rendered as a checkbox-style list (empty squares) so the reader mentally ticks them. Optional image slot [MOCKUP_PROBLEM]: flat-lay of crumpled receipts, a phone showing a generic banking screen (no real brand) and a calendar; muted tones. No stock photos of crying or distressed people. Keep tone empathetic, not alarmist. IMPORTANT: these lines are for the landing page only; do not reuse them as Meta/TikTok ad headlines or primary text, because they refer to the reader's personal financial situation (personal-attribute policy)._

## 03 · História e empatia (voz da marca)

**Não é falta de força de vontade**

Na maioria das vezes, falta um lugar simples para olhar o dinheiro de frente.

Aqui na [Nome da marca], a gente parte de uma ideia simples: quase todo mundo já tentou se organizar. Baixou aplicativo, começou planilha em janeiro, anotou num caderno... e parou em fevereiro.

Isso não acontece porque a pessoa é desorganizada. Acontece porque a ferramenta era complicada demais, ou porque faltava um caminho: o que anotar primeiro, o que olhar no fim do mês, o que fazer com o que sobrou ou com o que faltou.

Foi pensando nisso que criamos o Planner Financeiro 2027. Cada página tem um motivo para existir e um lugar certo na sua rotina. Nada de teoria difícil, nada de promessa milagrosa. Só um roteiro claro, página por página, para você enxergar o seu dinheiro e tomar decisões com mais calma.


[BOTÃO] Ver o que tem dentro do planner

_Design (para o Lovable): Speak as the brand only; no founder photo, no personal backstory, no invented numbers. Layout: narrow text column with a soft background block. Image slot [MOCKUP_STORY]: open planner showing a monthly budget spread partially filled in with handwriting (fictional, round values), a pencil case beside it; hands may appear but no face. Pull-quote styling for the sentence 'Não é falta de força de vontade'._

## 04 · Solução

**Planner Financeiro 2027: o seu ano inteiro organizado no papel**

Um roteiro mês a mês para você planejar, anotar, revisar e ajustar, no seu ritmo.

O planner segue uma lógica simples. Primeiro você define o que quer para 2027. Depois, a cada mês, monta o orçamento, acompanha as contas e registra o que pagou. No fim do mês, faz uma revisão rápida e leva o aprendizado para o mês seguinte.

Dívidas, reserva de emergência e economias ficam em páginas próprias, então você para de depender da memória e passa a ver tudo num lugar só.

Organizar não faz o dinheiro aparecer do nada, e a gente não vai fingir que faz. O que o planner oferece é um lugar para enxergar com antecedência o que vem pela frente: os vencimentos do mês, o total das dívidas, o quanto dá para guardar. Com isso à vista, fica mais fácil decidir cada gasto.

- Planeje: metas do ano e orçamento de cada mês
- Acompanhe: contas, gastos, dívidas e economias
- Revise: 12 revisões mensais com dicas para ajustar a rota
- Feche o ano: resumo anual para ver o caminho que você fez

[BOTÃO] Quero organizar meu 2027

_Design (para o Lovable): Four-step horizontal timeline on desktop (Planeje / Acompanhe / Revise / Feche o ano), vertical on mobile, each with a simple line icon. Image slot [MOCKUP_SOLUTION]: tablet and printed pages side by side showing the planner, to communicate 'imprima ou use no tablet'. No bold text in this section._

## 05 · O que tem dentro

**Veja tudo o que vem no seu planner**

PDF para imprimir com cerca de 50 páginas, organizado para acompanhar você de janeiro a dezembro de 2027.

Cada parte do planner foi pensada para uma tarefa específica. Você não precisa usar tudo de uma vez: comece pelo orçamento do mês e vá incluindo as outras páginas aos poucos.

Como é um PDF, você pode reimprimir as páginas mensais sempre que precisar, para uso pessoal e da sua família.

- Calendário 2027 com os feriados nacionais do Brasil, para planejar viagens, folgas e gastos de datas especiais
- Páginas de metas: o que você quer conquistar ou resolver em 2027
- 12 orçamentos mensais: renda, gastos fixos, gastos variáveis e quanto sobrou ou faltou
- Controle de contas a pagar: vencimento, valor e se já foi pago, para ajudar você a não esquecer nenhum boleto
- Controle de dívidas: com quem, quanto, juros e parcelas, tudo num lugar só
- Reserva de emergência: acompanhe, passo a passo, a construção do seu colchão de segurança
- Controle de economias: registre o que você está guardando e para quê
- Planejamento de compras: pense com antecedência nas compras maiores, antes de decidir no impulso
- 12 revisões mensais com dicas: o que deu certo, o que ajustar e qual o foco do próximo mês
- Resumo anual: uma visão do seu ano inteiro em uma página

[BOTÃO] Quero meu planner por R$27

_Design (para o Lovable): Grid of page thumbnails (2 columns mobile, 3-4 desktop), one card per bullet with a mini preview. Image slots: [MOCKUP_INSIDE_CALENDAR], [MOCKUP_INSIDE_GOALS], [MOCKUP_INSIDE_BUDGET], [MOCKUP_INSIDE_BILLS], [MOCKUP_INSIDE_DEBTS], [MOCKUP_INSIDE_EMERGENCY], [MOCKUP_INSIDE_SAVINGS], [MOCKUP_INSIDE_PURCHASES], [MOCKUP_INSIDE_REVIEW], [MOCKUP_INSIDE_ANNUAL]. Thumbnails must match the real final PDF pages (replace AI mockups with real screenshots once the PDF is final). Confirm the page count, that every listed field exists in the final file and that the 2027 national holidays are correct (check) before publishing. Optional short flip-through video embed slot [VIDEO_FLIPTHROUGH]._

## 06 · Prévia do order bump

**Quer uma ajuda extra para criar o hábito de guardar dinheiro?**

No checkout, você vai ver uma oferta opcional: Desafio das 52 Semanas: Kit Poupança, por R$9,90.

O planner organiza o seu ano. O Desafio das 52 Semanas transforma o hábito de guardar em um jogo: uma pequena missão por semana, marcada no papel, até completar o ano.

É totalmente opcional. Se você quiser, basta marcar a caixinha no checkout. Se não quiser, o planner funciona perfeitamente sozinho.

- 3 trackers para imprimir e ir preenchendo a cada semana concluída
- 52 minidesafios, um para cada semana do ano
- Ideal para quem quer criar o hábito de guardar, começando pequeno
- Entregue no mesmo e-mail do planner, com a mesma garantia de 7 dias

[BOTÃO] Quero o planner (o kit é opcional no checkout)

_Design (para o Lovable): Small, secondary section; boxed card with dashed border to echo the checkout bump. Image slot [MOCKUP_BUMP]: printed 52-week tracker partially colored in, with colored pencils and a glass jar of coins. Do not make it look mandatory and never pre-tick the bump box in the checkout. Confirm the 3 tracker formats and that the bump is delivered in the same email (check) before publishing._

## 07 · Como funciona

**Como funciona: tudo digital, direto no seu e-mail**

Nada é enviado pelo correio, então você não precisa esperar entrega.

Assim que o pagamento é aprovado, você recebe o acesso no e-mail informado na compra. No Pix, a confirmação costuma ser rápida; no cartão, pode depender da análise da operadora.

Depois é só baixar o PDF, salvar no celular e no computador e começar pela primeira página.

- 1. Escolha Pix ou cartão de crédito e finalize a compra no checkout
- 2. Receba o acesso no seu e-mail logo após a aprovação do pagamento
- 3. Imprima em casa, numa papelaria ou gráfica rápida, ou use no tablet em um aplicativo que permite escrever em PDF

[BOTÃO] Quero começar agora

_Design (para o Lovable): Three numbered cards in a row (stacked on mobile) with icons: Pix/card (generic icon; use the official Pix logo only if brand guidelines allow), envelope/download, printer/tablet. Image slot [MOCKUP_HOWITWORKS]: phone showing a generic 'acesso liberado' email next to a printer outputting the planner. Verify with the real test purchase (Pix from a Brazilian buyer + card) that delivery is really immediate and that the checkout shows prices in BRL; adjust the copy if not. Check whether card instalments are available and add 'em até Xx' only if confirmed._

## 08 · Para quem é

**Este planner é para você se...**

Você quer começar 2027 com mais clareza, mesmo que hoje esteja tudo bagunçado.

Não importa se você ganha pouco ou muito, se tem carteira assinada, trabalha por conta própria ou está com contas atrasadas. O ponto de partida é o mesmo: anotar, enxergar e decidir.

- Você vive no aperto do fim do mês e quer entender por quê
- Você tem dívidas ou parcelas e quer ver tudo num lugar só
- Você prefere papel e caneta a aplicativos e planilhas
- Você quer usar o 13º e o começo do ano com mais planejamento
- Você quer começar uma reserva de emergência, mesmo que pequena
- Sua renda muda de um mês para o outro e você quer acompanhar mês a mês
- Você quer organizar as finanças da casa junto com a família ou o parceiro

[BOTÃO] Sou eu, quero o planner

_Design (para o Lovable): Two-column comparison with not_for_who on desktop (for_who on the left, green check icons), stacked on mobile. No images needed; optional small illustration slot [MOCKUP_FORWHO] of a kitchen table with planner and bills, warm and calm. Landing page only: do not reuse these bullets as ad copy (personal-attribute policy)._

## 09 · Para quem não é

**E não é para você se...**

Preferimos ser honestos antes da compra.

O planner é uma ferramenta de organização. Ele não faz o trabalho por você nem substitui orientação profissional.

Se a sua situação de dívidas estiver muito grave, vale também buscar orientação gratuita em órgãos de defesa do consumidor da sua cidade, como o Procon.

- Você procura uma forma de enriquecer rápido ou de ganhar renda extra
- Você quer um aplicativo que se conecte automaticamente ao seu banco
- Você espera que alguém negocie suas dívidas por você
- Você não pretende dedicar nenhum tempo para anotar e revisar
- Você precisa de consultoria financeira, contábil ou jurídica individual

_Design (para o Lovable): Right column of the comparison block, neutral grey X icons (not red). No CTA button in this section. Keep the Procon line small but visible._

## 10 · Oferta

**Tudo o que você recebe hoje**

Pagamento único de R$27. Sem mensalidade.

Você paga uma vez e fica com o arquivo para usar durante todo o ano de 2027, reimprimindo as páginas mensais sempre que precisar, para uso pessoal e da sua família.

Na prática, são R$27 para um ano inteiro de páginas: cerca de R$2,25 por mês de 2027.

O pagamento pode ser feito por Pix ou cartão de crédito. O acesso chega no seu e-mail assim que o pagamento é aprovado.

- Planner Financeiro 2027 em PDF para imprimir (cerca de 50 páginas)
- Calendário 2027 com feriados nacionais do Brasil
- 12 orçamentos mensais + 12 revisões mensais com dicas
- Páginas de metas, contas, dívidas, reserva de emergência, economias e compras planejadas
- Resumo anual
- Garantia de 7 dias (direito de arrependimento, CDC art. 49)
- Opcional no checkout: Desafio das 52 Semanas: Kit Poupança por R$9,90

[BOTÃO] Quero meu Planner 2027 por R$27

_Design (para o Lovable): Centered offer card with a large product mockup slot [MOCKUP_OFFER_STACK] (planner cover plus 3 fanned interior pages). List items with check icons, no crossed-out 'de/por' prices and no invented 'valor total' anchor; the only anchor is the honest per-month math (R$27 / 12 = R$2,25). Price R$27 in large type, bold once. Payment icons row: Pix, credit card (generic). Add an instalment line only after confirming the checkout supports it._

## 11 · Garantia

**Garantia de 7 dias, sem complicação**

Você tem 7 dias para conhecer o planner com calma.

Pelo Código de Defesa do Consumidor (art. 49), compras feitas pela internet têm prazo de arrependimento de 7 dias. Se nesse período você achar que o planner não é para você, é só pedir o reembolso pelo [canal de suporte / plataforma de pagamento] e devolvemos o valor pago.

Sem perguntas difíceis e sem letras miúdas. Assim, o risco de testar fica com a gente, não com você.

- Prazo: 7 dias a partir da compra
- Reembolso do valor pago
- Pedido pelo [canal de suporte] ou diretamente na plataforma de pagamento

[BOTÃO] Comprar com garantia de 7 dias

_Design (para o Lovable): Badge/seal graphic with '7 dias' (designed seal, not a fake certification logo). Light background card. Fill [canal de suporte] with the real email/WhatsApp. Confirm the refund flow and refund timing on EscalePay/Hotmart with the test purchase before publishing (check)._

## 12 · Depoimentos

**O que dizem as pessoas que estão usando**

Depoimentos reais de clientes, publicados com autorização.

[Depoimento real do primeiro cliente]

[Depoimento real do segundo cliente]

[Depoimento real do terceiro cliente]

- INSTRUÇÃO: não publique esta seção até ter depoimentos reais. Nunca invente nomes, fotos, prints ou números.
- Peça depoimentos pelo e-mail de avaliação (dia 7 a 10) e guarde a autorização por escrito de cada pessoa.
- Use apenas primeiro nome e cidade, ou iniciais, se a pessoa preferir. Sem fotos de rosto sem autorização.
- Não edite o sentido do texto; corrija só erros de digitação, com permissão.
- Não publique depoimentos que falem em valores economizados ou dívidas quitadas como se fosse resultado garantido; se usar, inclua a frase: resultados variam de pessoa para pessoa.
- Fotos do planner preenchido enviadas por clientes são ótimas, desde que não mostrem dados pessoais ou bancários.

[BOTÃO] Quero meu planner também

_Design (para o Lovable): Hide this whole section (toggle off in Lovable) until at least 3 real, authorised testimonials exist. When live: card carousel, quote text, first name + city, optional customer photo of their filled planner with personal data blurred. Never use AI-generated faces or stock photos as 'customers'. The instruction bullets are internal and must not be rendered on the page._

## 13 · Introdução ao FAQ

**Ficou alguma dúvida?**

Separamos as perguntas mais comuns antes da compra.

Se a sua dúvida não estiver aqui, fale com a gente pelo [contato]. Respondemos o mais rápido possível.


_Design (para o Lovable): Short intro above an accordion FAQ component (render the faq array as collapsible items, first one open). Support contact as a clickable link (mailto or WhatsApp click-to-chat)._

## 14 · Chamada final

**O seu 2027 começa com a primeira página**

Planner Financeiro 2027 por R$27, acesso imediato após a aprovação e garantia de 7 dias.

Você não precisa resolver tudo de uma vez. Precisa só começar: anotar o que entra, o que sai e o que você deve.

Se você for anotando mês a mês, lá pelo meio do ano vai ter no papel o registro do caminho que fez: o que mudou, o que funcionou e o que ainda falta ajustar. É uma clareza que você constrói com as próprias mãos, no seu ritmo.

- PDF com cerca de 50 páginas para imprimir
- Pix ou cartão de crédito
- Acesso imediato após a aprovação do pagamento
- Garantia de 7 dias

[BOTÃO] Quero meu Planner 2027 por R$27

_Design (para o Lovable): Full-width band with the brand's calm green background, white text, big CTA. Image slot [MOCKUP_FINAL]: planner open to the annual summary page beside a 2027 wall calendar, morning light. No countdown timers, 'últimas unidades' or 'vagas limitadas' elements._

## 15 · Rodapé

**[Nome da marca]**

Produtos digitais educativos em português.

Vendido por: [Nome]

Identificação: [NUIT/identificação]

Contato: [contato] | Endereço: [endereço completo - check]

Pagamento processado por [EscalePay / Hotmart].

Este produto é educativo e não constitui consultoria financeira, contábil ou jurídica. Os resultados dependem do uso e da situação de cada pessoa.

- Política de Privacidade (LGPD)
- Termos de Uso
- Política de Reembolso (7 dias)
- Contato e suporte

_Design (para o Lovable): Small-type footer, dark neutral background. Fill all bracketed seller identification fields before publishing (check exact requirements of Decreto 7.962/2013: name, identification number, physical and electronic address). Link to a PT-BR privacy policy page explaining data use, marketing consent and how to request deletion. Add copyright line and year._

## FAQ

**Como eu recebo o planner?**

Assim que o pagamento é aprovado, você recebe no e-mail informado na compra o link para baixar o PDF. Se não encontrar, confira a caixa de spam e a aba Promoções, ou fale com a gente pelo [contato].

**O planner é físico? Vou receber algo em casa?**

Não. É um produto 100% digital, em PDF. Nada é enviado pelo correio. Você imprime as páginas ou usa no tablet.

**Preciso ter impressora?**

Não necessariamente. Você pode imprimir em casa, numa papelaria ou gráfica rápida, ou abrir o PDF no tablet em um aplicativo que permita escrever sobre PDF.

**Qual o tamanho das páginas?**

O planner foi feito em tamanho [A4 - check no arquivo final], o tamanho padrão de impressão no Brasil.

**Posso imprimir mais de uma vez?**

Pode, sim. Você pode reimprimir as páginas sempre que precisar, para uso pessoal e da sua família. Só não é permitido revender, compartilhar ou distribuir o arquivo.

**Comprei antes de 2027. Já dá para começar?**

Dá, e é até uma boa ideia. Use as semanas antes da virada para preencher as metas, listar suas contas fixas e anotar todas as dívidas. Assim você começa janeiro com tudo anotado e com mais clareza sobre por onde ir.

**Tenho dívidas. O planner vai resolver isso?**

O planner não negocia nem quita dívidas, e ninguém honesto pode prometer isso. O que ele faz é colocar todas as dívidas num lugar só, com valores, juros e parcelas, para você enxergar o tamanho real da situação e planejar os próximos passos. Em casos mais graves, vale buscar também orientação gratuita no Procon da sua cidade.

**Não sou bom com números. Vou conseguir usar?**

O planner foi feito pensando justamente nisso. Ele usa só contas simples de somar e subtrair, que você pode fazer na calculadora do celular, e cada página indica o que anotar em cada campo.

**Minha renda muda todo mês. O planner serve para mim?**

Serve. O orçamento é montado mês a mês, então você anota a renda real de cada mês e ajusta os gastos a partir dela. As revisões mensais ajudam a perceber os meses mais apertados e a se preparar para eles.

**Dá para usar a dois ou com a família?**

Dá. Muita gente prefere preencher junto, numa conversa fixa por semana ou por mês. Como você pode reimprimir as páginas para uso pessoal e da sua família, cada pessoa também pode ter as suas folhas.

**O calendário tem os feriados do meu estado e da minha cidade?**

O calendário traz os feriados nacionais do Brasil. Os feriados estaduais e municipais variam muito, então vale anotar os da sua cidade nos espaços do calendário.

**Qual a diferença entre o planner e uma planilha?**

O planner é para quem gosta de papel e caneta e quer um ritual de organização. Depois da compra, você vai ver uma oferta opcional da Planilha Financeira 2027, para quem também quer os cálculos automáticos no computador ou no celular. Não é obrigatório: o planner funciona sozinho.

**Quais são as formas de pagamento?**

Pix e cartão de crédito. [check: confirmar parcelamento e moeda exibida no checkout após a compra-teste]

**E se eu não gostar?**

Você tem 7 dias a partir da compra para pedir o reembolso, conforme o art. 49 do Código de Defesa do Consumidor. É só pedir pelo [contato] ou pela plataforma de pagamento e devolvemos o valor pago.

**Quem está vendendo?**

O planner é da [Nome da marca], vendido por [Nome], [NUIT/identificação]. Os dados completos e o contato estão no rodapé desta página. O pagamento é processado pela [EscalePay / Hotmart].


## Checkout: order bump

**Sim! Quero adicionar o Desafio das 52 Semanas: Kit Poupança por apenas R$9,90**

Transforme o hábito de guardar dinheiro num jogo de uma missão por semana. Você recebe 3 trackers para imprimir e ir preenchendo e 52 minidesafios, um para cada semana de 2027. Combina direitinho com o planner e é entregue no mesmo e-mail. Totalmente opcional: marque a caixinha só se fizer sentido para você.


## /obrigado

**Pronto! Seu Planner Financeiro 2027 já está a caminho**



Obrigado pela confiança. O acesso foi enviado para o e-mail que você informou na compra.

Se ele não aparecer em alguns minutos, confira a caixa de spam e a aba Promoções. Se mesmo assim não encontrar, fale com a gente pelo [contato] informando o e-mail da compra.

Uma dica para começar bem: não tente preencher tudo hoje. Comece por uma página só, a de contas a pagar, e liste todas as contas fixas da casa. Esse primeiro retrato já ajuda a enxergar o seu mês com mais clareza.

- Abra o e-mail de acesso e baixe o PDF (salve no celular e no computador)
- Imprima primeiro as páginas de metas, contas a pagar e dívidas
- Liste todas as contas fixas e todas as dívidas, mesmo as pequenas
- Marque na agenda um horário fixo por semana para atualizar o planner
- No fim do mês, faça a revisão mensal e defina o foco do mês seguinte

[upsell_teaser] Antes de sair: preparamos uma oferta opcional para quem também quer os cálculos automáticos no computador ou no celular. Veja na próxima página.

## /oferta-especial (upsell)

**Quer que os cálculos sejam feitos para você?**

Adicione a Planilha Financeira 2027 + Guia Saia das Dívidas ao seu pedido por R$37.

O planner em papel ajuda você a criar o hábito e enxergar o seu mês. A planilha complementa: você digita os valores e ela soma, calcula e mostra tudo num painel, sem você precisar fazer conta.

E se você tem mais de uma dívida, a calculadora mostra duas formas conhecidas de organizar a ordem de pagamento: o método bola de neve (começando pelas menores dívidas) e o método avalanche (começando pelos juros mais altos). Você compara as simulações e escolhe o que faz mais sentido para a sua realidade.

Junto vem o Guia Saia das Dívidas, com cerca de 25 páginas de conteúdo educativo para você entender juros, priorizar pagamentos e se preparar para conversar com credores. O guia explica caminhos possíveis; ele não garante quitação nem negocia por você.

É totalmente opcional. O planner que você comprou já funciona sozinho.

- Planilha Financeira 2027 para Excel e Google Sheets
- Painel (dashboard) com o resumo do seu mês e do seu ano
- Calculadora de dívidas com os métodos bola de neve e avalanche
- Guia Saia das Dívidas: cerca de 25 páginas de conteúdo educativo
- Entregue no mesmo e-mail do planner, com garantia de 7 dias
- Conteúdo educativo: não substitui orientação financeira profissional

[cta_yes] Sim, quero adicionar a Planilha + Guia por R$37

[cta_no] Não, obrigado. Vou seguir só com o planner em papel.

## /segunda-chance (downsell)

**Entendido. Que tal só a planilha?**

Planilha Financeira 2027, sem o guia, por R$19,90.

Se o guia não é o que você precisa agora, tudo bem. Você pode levar só a Planilha Financeira 2027, com o painel e a calculadora de dívidas, para ter os cálculos automáticos ao lado do seu planner.

É uma oferta opcional, adicionada ao seu pedido, e também tem garantia de 7 dias.

- Planilha Financeira 2027 para Excel e Google Sheets
- Painel (dashboard) com o resumo do mês e do ano
- Calculadora de dívidas com os métodos bola de neve e avalanche
- Entregue no mesmo e-mail do seu pedido
- Garantia de 7 dias

[cta_yes] Sim, quero só a planilha por R$19,90

[cta_no] Não, obrigado. Quero ir para o meu acesso.

## /afiliados

**Divulgue o Planner Financeiro 2027 e receba 50% de comissão**



Se você fala com um público que quer organizar o dinheiro, você pode indicar o Planner Financeiro 2027 e receber 50% de comissão sobre cada venda do produto principal (R$27) feita pelo seu link, ou seja, até R$13,50 por venda. [check: confirmar na plataforma se a comissão é calculada sobre o valor bruto ou líquido de taxas, o prazo de cookie, o prazo de pagamento e as regras de comissão para order bump e upsell.]

Você recebe materiais prontos para divulgar: mockups do produto, prévias das páginas, sugestões de texto e ideias de vídeos de folheio, que funcionam bem em perfil dark (sem aparecer).

A gente só trabalha com divulgação honesta. Organização financeira é um tema sensível: muita gente está cansada de promessas. Por isso, as regras abaixo não são opcionais. Quem descumprir pode ter a afiliação cancelada e as comissões revisadas conforme as regras da plataforma.

- Comissão: 50% sobre o Planner Financeiro 2027 (R$27), conforme as regras da plataforma
- Proibido prometer resultados: nada de 'saia das dívidas em X dias', 'economize R$ X' ou qualquer garantia de ganho ou economia
- Proibido falar em renda extra ou ganhar dinheiro com o planner: é um produto de organização, não de renda
- Proibido spam: nada de mensagens em massa no WhatsApp, Telegram, e-mail ou direct para quem não pediu
- Proibido inventar depoimentos, prints, números, rankings, 'mais vendido' ou escassez falsa
- Proibido usar a marca ou o nome do produto em anúncios de pesquisa paga sem autorização
- Anúncios devem seguir as políticas da Meta e do TikTok, sem textos que apontem condições pessoais (ex.: 'você está endividado?') e com rótulo de IA quando houver pessoas ou cenas realistas geradas por IA
- Não se apresente como a marca oficial nem como consultor financeiro
- Dúvidas sobre o que pode ou não pode: fale antes com [contato]

[cta] Quero me afiliar

## Cadastro na EscalePay / Hotmart

**EscalePay:** Planner Financeiro 2027 para Imprimir (PDF) - Orçamento, Contas e Dívidas

Organize o seu dinheiro em 2027 com um planner em PDF para imprimir, com cerca de 50 páginas. Inclui calendário 2027 com feriados nacionais do Brasil, páginas de metas, 12 orçamentos mensais, controle de contas a pagar, controle de dívidas, reserva de emergência, economias, planejamento de compras, 12 revisões mensais com dicas e resumo anual. Feito para quem quer entender o aperto do fim do mês e enxergar para onde vai cada real. Produto digital educativo, sem promessa de resultado, para uso pessoal. Acesso imediato após a aprovação do pagamento. Pix ou cartão. Garantia de 7 dias.

**Hotmart:** Planner Financeiro 2027: organize seu dinheiro mês a mês (PDF para imprimir)

Planner Financeiro 2027 em PDF para imprimir, com cerca de 50 páginas para organizar suas finanças de janeiro a dezembro. Você planeja metas, monta o orçamento de cada mês, acompanha contas e vencimentos, coloca todas as dívidas num lugar só, acompanha a reserva de emergência e as economias e faz 12 revisões mensais com dicas. Traz calendário 2027 com feriados nacionais e resumo anual. Ideal para quem prefere papel e caneta. Conteúdo educativo, sem promessa de resultado. Acesso imediato após a aprovação do pagamento e garantia de 7 dias.

Palavras-chave: planner financeiro 2027, planner financeiro para imprimir, controle financeiro, organizar as finanças, orçamento mensal, planejamento financeiro 2027, controle de gastos, controle de dívidas, reserva de emergência, desafio das 52 semanas


## Mensagens de acompanhamento

### 1. Acesso ao produto (imediato) (email)

```
Assunto: Seu Planner Financeiro 2027 chegou

Oi, [primeiro nome]!

Obrigado pela compra. Aqui está o seu acesso ao Planner Financeiro 2027:

[LINK DE ACESSO]

Salve o PDF no celular e no computador, assim você não perde.

Para começar sem se sobrecarregar, faça só isto hoje: imprima a página de contas a pagar e liste todas as contas fixas da casa. Só isso. Amanhã a gente manda a próxima dica.

Qualquer problema com o acesso, é só responder este e-mail ou falar com a gente pelo [contato].

Um abraço,
Equipe [Nome da marca]

Você tem 7 dias de garantia a partir da compra (CDC, art. 49).
```

### 2. Dica do dia 2 (WhatsApp (somente para quem autorizou) ou email)

```
Oi, [primeiro nome]! Aqui é da [Nome da marca], do Planner Financeiro 2027.

Dica de hoje: abra a página de dívidas e anote todas, até aquela parcela pequena da loja ou o valor que você deve para alguém da família. Coloque quanto falta, os juros (se tiver) e o valor da parcela.

Pode ser desconfortável no começo, mas é o primeiro passo para sair do escuro. Para muita gente, ver o número real assusta menos do que ficar imaginando.

Se quiser parar de receber mensagens, é só responder SAIR.
```

### 3. Lembrete da planilha (dia 3) (email (somente para quem autorizou comunicações de marketing))

```
Assunto: Para quem também quer os cálculos automáticos

Oi, [primeiro nome]!

Depois da compra, você viu uma oferta opcional e talvez tenha passado direto. Sem problema, só queria deixar registrado caso faça sentido agora.

A Planilha Financeira 2027 + Guia Saia das Dívidas complementa o seu planner: você digita os valores e a planilha soma tudo e mostra um painel do mês e do ano. A calculadora de dívidas compara os métodos bola de neve e avalanche, e o guia traz cerca de 25 páginas de conteúdo educativo sobre juros e prioridades de pagamento.

O valor é R$37, com garantia de 7 dias: [LINK DA OFERTA]

Se preferir ficar só com o planner em papel, ele funciona perfeitamente sozinho. Este é o único lembrete sobre a planilha.

Um abraço,
Equipe [Nome da marca]

Para não receber mais e-mails: [link de descadastro]
```

### 4. Pedido de avaliação (dia 7 a 10) (email)

```
Assunto: Posso te pedir um favor rápido?

Oi, [primeiro nome]!

Já faz alguns dias que o Planner Financeiro 2027 está com você. Como está sendo?

Se puder, responda este e-mail com duas ou três frases contando o que achou: o que ajudou, o que ficou confuso, o que você mudaria. A sua opinião, boa ou ruim, ajuda a gente a melhorar o produto.

Se quiser que a gente publique o seu comentário na página, diga no final: Autorizo a publicação com meu primeiro nome e cidade. Sem essa autorização, nada é publicado. E, se quiser mandar uma foto do planner preenchido, cubra antes os valores e dados pessoais.

Obrigado de verdade,
Equipe [Nome da marca]

Para não receber mais e-mails: [link de descadastro]
```

### 5. Cross-sell das outras famílias (dia 14) (email (somente para quem autorizou comunicações de marketing))

```
Assunto: Outros materiais da [Nome da marca] que podem te interessar

Oi, [primeiro nome]!

Além do Planner Financeiro 2027, a gente tem outros materiais para imprimir que talvez façam sentido para você ou para alguém da sua casa:

Caderno do Casal: 52 Encontros para Reconectar (R$27). Um encontro por semana, com 5 perguntas, um desafio e uma ideia de programa barato a dois. Inclusive tem perguntas sobre sonhos e planos, que combinam com as metas do seu planner: [LINK]

Kit Natal na Escola: 100+ Atividades para Imprimir (R$27). Atividades de Natal para crianças, como labirintos, caça-palavras, ligue os pontos, matemática natalina e calendário do Advento. Feito para pais, mães e professores usarem com os pequenos: [LINK]

[Enviar este parágrafo apenas entre 27 e 30/11/2026:] Na Black Friday, de 27 a 30 de novembro, o Mega Kit 2027 reúne os 9 materiais da [Nome da marca] por R$67. Depois disso, ele passa a custar R$97: [LINK]

Um abraço,
Equipe [Nome da marca]

Para não receber mais e-mails: [link de descadastro]

[Nota interna, apagar antes de enviar: não usar o preço-âncora R$207,60 sem conferir; a soma dos 9 preços individuais dá R$207,70. Só mencionar 'depois passa a custar R$97' se o preço realmente mudar no dia 1/12.]
```

### 6. Checkout abandonado (somente com consentimento) (email ou WhatsApp (enviar apenas se a pessoa marcou o consentimento de contato no checkout))

```
Oi, [primeiro nome]! Aqui é da [Nome da marca].

Vimos que você começou a compra do Planner Financeiro 2027, mas ela não foi concluída. Às vezes é só um problema com o Pix, o cartão ou a internet.

Se ainda quiser, o link é este: [LINK DO CHECKOUT]

O valor continua R$27, com acesso imediato após a aprovação e garantia de 7 dias. Se tiver alguma dúvida antes de comprar, é só responder esta mensagem.

Se não quiser receber mais mensagens, responda SAIR. Esta é a única mensagem sobre este pedido.
```


## Avisos legais

- Produto digital educativo. Não constitui consultoria financeira, contábil, jurídica ou de investimentos.
- Não garantimos resultados como economia de valores, quitação de dívidas ou aumento de renda. Os resultados dependem do uso e da situação de cada pessoa.
- Direito de arrependimento: você pode pedir o reembolso do valor pago em até 7 dias a partir da compra, conforme o art. 49 do Código de Defesa do Consumidor.
- O calendário traz os feriados nacionais do Brasil. Confira os feriados estaduais e municipais da sua cidade.
- Licença de uso pessoal e familiar. É proibido revender, compartilhar ou distribuir os arquivos.
- Quando exibidos, os depoimentos são de clientes reais, publicados com autorização. Resultados variam de pessoa para pessoa.
- Seus dados são tratados conforme a LGPD. Mensagens de marketing só são enviadas com o seu consentimento, e você pode cancelar a qualquer momento. Veja a Política de Privacidade.
- Vendido por [Nome], [NUIT/identificação], [contato]. Pagamento processado por [EscalePay / Hotmart].